package com.flansmod.client.model.hltp;

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelSPAS extends ModelGun
{
	int textureX = 512;
	int textureY = 256;

	public ModelSPAS()
	{
		gunModel = new ModelRendererTurbo[83];
		gunModel[0] = new ModelRendererTurbo(this, 80, 2, textureX, textureY); // barrel1-2
		gunModel[1] = new ModelRendererTurbo(this, 80, 49, textureX, textureY); // body1
		gunModel[2] = new ModelRendererTurbo(this, 80, 67, textureX, textureY); // pump1
		gunModel[3] = new ModelRendererTurbo(this, 80, 81, textureX, textureY); // pump2
		gunModel[4] = new ModelRendererTurbo(this, 1, 60, textureX, textureY); // stock1
		gunModel[5] = new ModelRendererTurbo(this, 1, 45, textureX, textureY); // Box 1
		gunModel[6] = new ModelRendererTurbo(this, 29, 44, textureX, textureY); // Box 2
		gunModel[7] = new ModelRendererTurbo(this, 51, 48, textureX, textureY); // Box 3
		gunModel[8] = new ModelRendererTurbo(this, 42, 48, textureX, textureY); // Box 4
		gunModel[9] = new ModelRendererTurbo(this, 16, 44, textureX, textureY); // Box 5
		gunModel[10] = new ModelRendererTurbo(this, 142, 41, textureX, textureY); // Box 6
		gunModel[11] = new ModelRendererTurbo(this, 34, 84, textureX, textureY); // Box 7
		gunModel[12] = new ModelRendererTurbo(this, 95, 49, textureX, textureY); // Box 8
		gunModel[13] = new ModelRendererTurbo(this, 119, 41, textureX, textureY); // Box 9
		gunModel[14] = new ModelRendererTurbo(this, 154, 51, textureX, textureY); // Box 10
		gunModel[15] = new ModelRendererTurbo(this, 80, 39, textureX, textureY); // Box 11
		gunModel[16] = new ModelRendererTurbo(this, 107, 20, textureX, textureY); // Box 12
		gunModel[17] = new ModelRendererTurbo(this, 107, 26, textureX, textureY); // Box 16
		gunModel[18] = new ModelRendererTurbo(this, 139, 49, textureX, textureY); // Box 17
		gunModel[19] = new ModelRendererTurbo(this, 118, 49, textureX, textureY); // Box 18
		gunModel[20] = new ModelRendererTurbo(this, 80, 31, textureX, textureY); // Box 19
		gunModel[21] = new ModelRendererTurbo(this, 146, 31, textureX, textureY); // Box 20
		gunModel[22] = new ModelRendererTurbo(this, 21, 59, textureX, textureY); // Box 21
		gunModel[23] = new ModelRendererTurbo(this, 60, 40, textureX, textureY); // Box 22
		gunModel[24] = new ModelRendererTurbo(this, 60, 49, textureX, textureY); // Box 25
		gunModel[25] = new ModelRendererTurbo(this, 31, 105, textureX, textureY); // Box 26
		gunModel[26] = new ModelRendererTurbo(this, 1, 78, textureX, textureY); // Box 27
		gunModel[27] = new ModelRendererTurbo(this, 1, 93, textureX, textureY); // Box 28
		gunModel[28] = new ModelRendererTurbo(this, 16, 102, textureX, textureY); // Box 0
		gunModel[29] = new ModelRendererTurbo(this, 1, 102, textureX, textureY); // Box 1
		gunModel[30] = new ModelRendererTurbo(this, 34, 93, textureX, textureY); // Box 2
		gunModel[31] = new ModelRendererTurbo(this, 34, 93, textureX, textureY); // Box 3
		gunModel[32] = new ModelRendererTurbo(this, 20, 69, textureX, textureY); // Box 4
		gunModel[33] = new ModelRendererTurbo(this, 55, 60, textureX, textureY); // Box 8
		gunModel[34] = new ModelRendererTurbo(this, 55, 69, textureX, textureY); // Box 9
		gunModel[35] = new ModelRendererTurbo(this, 46, 109, textureX, textureY); // Box 10
		gunModel[36] = new ModelRendererTurbo(this, 46, 101, textureX, textureY); // Box 11
		gunModel[37] = new ModelRendererTurbo(this, 46, 101, textureX, textureY); // Box 12
		gunModel[38] = new ModelRendererTurbo(this, 80, 92, textureX, textureY); // Box 13
		gunModel[39] = new ModelRendererTurbo(this, 169, 69, textureX, textureY); // Box 14
		gunModel[40] = new ModelRendererTurbo(this, 169, 80, textureX, textureY); // Box 15
		gunModel[41] = new ModelRendererTurbo(this, 169, 91, textureX, textureY); // Box 16
		gunModel[42] = new ModelRendererTurbo(this, 1, 33, textureX, textureY); // Box 17
		gunModel[43] = new ModelRendererTurbo(this, 1, 33, textureX, textureY); // Box 18
		gunModel[44] = new ModelRendererTurbo(this, 20, 33, textureX, textureY); // Box 19
		gunModel[45] = new ModelRendererTurbo(this, 1, 17, textureX, textureY); // Box 20
		gunModel[46] = new ModelRendererTurbo(this, 20, 33, textureX, textureY); // Box 21
		gunModel[47] = new ModelRendererTurbo(this, 1, 25, textureX, textureY); // Box 20
		gunModel[48] = new ModelRendererTurbo(this, 36, 31, textureX, textureY); // Box 20
		gunModel[49] = new ModelRendererTurbo(this, 36, 34, textureX, textureY); // Box 20
		gunModel[50] = new ModelRendererTurbo(this, 36, 25, textureX, textureY); // Box 20
		gunModel[51] = new ModelRendererTurbo(this, 10, 25, textureX, textureY); // Box 20
		gunModel[52] = new ModelRendererTurbo(this, 29, 25, textureX, textureY); // Box 20
		gunModel[53] = new ModelRendererTurbo(this, 1, 8, textureX, textureY); // Box 40
		gunModel[54] = new ModelRendererTurbo(this, 10, 25, textureX, textureY); // Box 20
		gunModel[55] = new ModelRendererTurbo(this, 1, 25, textureX, textureY); // Box 20
		gunModel[56] = new ModelRendererTurbo(this, 1, 17, textureX, textureY); // Box 20
		gunModel[57] = new ModelRendererTurbo(this, 29, 25, textureX, textureY); // Box 20
		gunModel[58] = new ModelRendererTurbo(this, 1, 117, textureX, textureY); // Box 20
		gunModel[59] = new ModelRendererTurbo(this, 44, 17, textureX, textureY); // Box 20
		gunModel[60] = new ModelRendererTurbo(this, 31, 9, textureX, textureY); // Box 52
		gunModel[61] = new ModelRendererTurbo(this, 48, 10, textureX, textureY); // Box 53
		gunModel[62] = new ModelRendererTurbo(this, 48, 10, textureX, textureY); // Box 54
		gunModel[63] = new ModelRendererTurbo(this, 48, 10, textureX, textureY); // Box 55
		gunModel[64] = new ModelRendererTurbo(this, 48, 10, textureX, textureY); // Box 56
		gunModel[65] = new ModelRendererTurbo(this, 16, 11, textureX, textureY); // Box 57
		gunModel[66] = new ModelRendererTurbo(this, 80, 11, textureX, textureY); // Box 0
		gunModel[67] = new ModelRendererTurbo(this, 174, 9, textureX, textureY); // Box 2
		gunModel[68] = new ModelRendererTurbo(this, 143, 9, textureX, textureY); // Box 3
		gunModel[69] = new ModelRendererTurbo(this, 36, 25, textureX, textureY); // Box 6
		gunModel[70] = new ModelRendererTurbo(this, 36, 25, textureX, textureY); // Box 8
		gunModel[71] = new ModelRendererTurbo(this, 36, 25, textureX, textureY); // Box 11
		gunModel[72] = new ModelRendererTurbo(this, 36, 34, textureX, textureY); // Box 12
		gunModel[73] = new ModelRendererTurbo(this, 36, 25, textureX, textureY); // Box 13
		gunModel[74] = new ModelRendererTurbo(this, 36, 31, textureX, textureY); // Box 14
		gunModel[75] = new ModelRendererTurbo(this, 36, 25, textureX, textureY); // Box 15
		gunModel[76] = new ModelRendererTurbo(this, 129, 3, textureX, textureY); // Box 16
		gunModel[77] = new ModelRendererTurbo(this, 29, 125, textureX, textureY); // Box 19
		gunModel[78] = new ModelRendererTurbo(this, 20, 125, textureX, textureY); // Box 20
		gunModel[79] = new ModelRendererTurbo(this, 70, 129, textureX, textureY); // Box 21
		gunModel[80] = new ModelRendererTurbo(this, 63, 129, textureX, textureY); // Box 22
		gunModel[81] = new ModelRendererTurbo(this, 40, 129, textureX, textureY); // Box 23
		gunModel[82] = new ModelRendererTurbo(this, 1, 125, textureX, textureY); // Box 24

		gunModel[0].addBox(0F, 0F, 0F, 20, 4, 4, 0F); // barrel1-2
		gunModel[0].setRotationPoint(66F, -24.5F, -2F);

		gunModel[1].addShapeBox(0F, 0F, 0F, 1, 11, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 10F, 0F, 0F, 10F, 0F, 0F, 0F, 0F, 0F); // body1
		gunModel[1].setRotationPoint(-8F, -24.5F, -3F);

		gunModel[2].addBox(0F, 0F, 0F, 36, 5, 8, 0F); // pump1
		gunModel[2].setRotationPoint(30F, -19.5F, -4F);

		gunModel[3].addShapeBox(0F, 0F, 0F, 36, 2, 8, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F); // pump2
		gunModel[3].setRotationPoint(30F, -14.5F, -4F);

		gunModel[4].addShapeBox(0F, 0F, 0F, 5, 13, 4, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F); // stock1
		gunModel[4].setRotationPoint(-13F, -25.5F, -2F);

		gunModel[5].addShapeBox(0F, 0F, 0F, 3, 9, 4, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F); // Box 1
		gunModel[5].setRotationPoint(-16F, -23.5F, -2F);

		gunModel[6].addShapeBox(0F, 0F, 0F, 5, 13, 1, 0F, 0F, -3F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -3F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, -2F, 0F); // Box 2
		gunModel[6].setRotationPoint(-13F, -25.5F, -3F);

		gunModel[7].addShapeBox(0F, 0F, 0F, 3, 9, 1, 0F, -1F, -3F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, -1F, -3F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, -3F, 0F); // Box 3
		gunModel[7].setRotationPoint(-16F, -23.5F, -3F);

		gunModel[8].addShapeBox(0F, 0F, 0F, 3, 9, 1, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, -1F, -3F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, -1F, -3F, 0F); // Box 4
		gunModel[8].setRotationPoint(-16F, -23.5F, 2F);

		gunModel[9].addShapeBox(0F, 0F, 0F, 5, 13, 1, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -3F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -3F, 0F); // Box 5
		gunModel[9].setRotationPoint(-13F, -25.5F, 2F);

		gunModel[10].addShapeBox(0F, 0F, 0F, 1, 1, 6, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 6
		gunModel[10].setRotationPoint(-8F, -25.5F, -3F);

		gunModel[11].addShapeBox(0F, 0F, 0F, 11, 2, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F); // Box 7
		gunModel[11].setRotationPoint(-8F, -13.5F, -3F);

		gunModel[12].addBox(0F, 0F, 0F, 5, 11, 6, 0F); // Box 8
		gunModel[12].setRotationPoint(25F, -24.5F, -3F);

		gunModel[13].addShapeBox(0F, 0F, 0F, 5, 1, 6, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 9
		gunModel[13].setRotationPoint(25F, -25.5F, -3F);

		gunModel[14].addBox(0F, 0F, 0F, 17, 11, 4, 0F); // Box 10
		gunModel[14].setRotationPoint(8F, -24.5F, -1F);

		gunModel[15].addBox(0F, 0F, 0F, 17, 7, 2, 0F); // Box 11
		gunModel[15].setRotationPoint(8F, -20.5F, -3F);

		gunModel[16].addShapeBox(0F, 0F, 0F, 11, 1, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 12
		gunModel[16].setRotationPoint(14F, -25.5F, -1F);

		gunModel[17].addBox(0F, 0F, 0F, 6, 3, 1, 0F); // Box 16
		gunModel[17].setRotationPoint(8F, -24.5F, -3F);

		gunModel[18].addShapeBox(0F, 0F, 0F, 1, 11, 6, 0F, 10F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 10F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 17
		gunModel[18].setRotationPoint(3F, -24.5F, -3F);

		gunModel[19].addBox(0F, 0F, 0F, 4, 11, 6, 0F); // Box 18
		gunModel[19].setRotationPoint(4F, -24.5F, -3F);

		gunModel[20].addShapeBox(0F, 0F, 0F, 27, 1, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 19
		gunModel[20].setRotationPoint(3F, -13.5F, -3F);

		gunModel[21].addShapeBox(0F, 0F, 0F, 21, 1, 6, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 20
		gunModel[21].setRotationPoint(-7F, -25.5F, -3F);

		gunModel[22].addBox(0F, 0F, 0F, 10, 3, 6, 0F); // Box 21
		gunModel[22].setRotationPoint(-7F, -11.5F, -3F);

		gunModel[23].addShapeBox(0F, 0F, 0F, 1, 2, 6, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, -1F, 0F, -1F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, -1F); // Box 22
		gunModel[23].setRotationPoint(-9F, -13.5F, -3F);

		gunModel[24].addShapeBox(0F, 0F, 0F, 1, 3, 6, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F); // Box 25
		gunModel[24].setRotationPoint(-8F, -11.5F, -3F);

		gunModel[25].addShapeBox(0F, 0F, 0F, 1, 5, 6, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F); // Box 26
		gunModel[25].setRotationPoint(3F, -13.5F, -3F);

		gunModel[26].addShapeBox(0F, 0F, 0F, 10, 8, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 4F, 0F, 0F, -4F, 0F, 0F, -4F, 0F, 0F, 4F, 0F, 0F); // Box 27
		gunModel[26].setRotationPoint(-7F, -8.5F, -3F);

		gunModel[27].addBox(0F, 0F, 0F, 10, 2, 6, 0F); // Box 28
		gunModel[27].setRotationPoint(-11F, -0.5F, -3F);

		gunModel[28].addShapeBox(0F, 0F, 0F, 1, 8, 6, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 4F, 0F, 0F, -4F, 0F, -1F, -4F, 0F, -1F, 4F, 0F, 0F); // Box 0
		gunModel[28].setRotationPoint(3F, -8.5F, -3F);

		gunModel[29].addShapeBox(0F, 0F, 0F, 1, 8, 6, 0F, -4F, 0F, -1F, 4F, 0F, 0F, 4F, 0F, 0F, -4F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F); // Box 1
		gunModel[29].setRotationPoint(-12F, -8.5F, -3F);

		gunModel[30].addShapeBox(0F, 0F, 0F, 1, 2, 6, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F); // Box 2
		gunModel[30].setRotationPoint(-1F, -0.5F, -3F);

		gunModel[31].addShapeBox(0F, 0F, 0F, 1, 2, 6, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F); // Box 3
		gunModel[31].setRotationPoint(-12F, -0.5F, -3F);

		gunModel[32].addShapeBox(0F, 0F, 0F, 11, 2, 6, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F); // Box 4
		gunModel[32].setRotationPoint(-11F, 1.5F, -3F);

		gunModel[33].addShapeBox(0F, 0F, 0F, 1, 2, 6, 0F, 1F, 0F, 0F, -1F, 0F, -1F, -1F, 0F, -1F, 1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F); // Box 8
		gunModel[33].setRotationPoint(0F, 1.5F, -3F);

		gunModel[34].addShapeBox(0F, 0F, 0F, 1, 2, 6, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, -1F, 0F, -1F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, -1F); // Box 9
		gunModel[34].setRotationPoint(-12F, 1.5F, -3F);

		gunModel[35].addShapeBox(0F, 0F, 0F, 7, 1, 6, 0F, 2F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, 2F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 10
		gunModel[35].setRotationPoint(-8F, 3.5F, -3F);

		gunModel[36].addShapeBox(0F, 0F, 0F, 1, 1, 6, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, -2F, 0F, -2F, 2F, 0F, -1F, 2F, 0F, -1F, -2F, 0F, -2F); // Box 11
		gunModel[36].setRotationPoint(-11F, 3.5F, -3F);

		gunModel[37].addShapeBox(0F, 0F, 0F, 1, 1, 6, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 1F, 0F, -1F, -1F, 0F, -2F, -1F, 0F, -2F, 1F, 0F, -1F); // Box 12
		gunModel[37].setRotationPoint(0F, 3.5F, -3F);

		gunModel[38].addBox(0F, 0F, 0F, 36, 2, 8, 0F); // Box 13
		gunModel[38].setRotationPoint(30F, -24.5F, -4F);

		gunModel[39].addBox(0F, 0F, 0F, 33, 3, 7, 0F); // Box 14
		gunModel[39].setRotationPoint(33F, -22.5F, -3.5F);

		gunModel[40].addShapeBox(0F, 0F, 0F, 36, 2, 8, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 15
		gunModel[40].setRotationPoint(30F, -26.5F, -4F);

		gunModel[41].addBox(0F, 0F, 0F, 3, 3, 8, 0F); // Box 16
		gunModel[41].setRotationPoint(30F, -22.5F, -4F);

		gunModel[42].addShapeBox(0F, 0F, 0F, 2, 1, 7, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 17
		gunModel[42].setRotationPoint(-14F, -19.5F, -3.5F);

		gunModel[43].addShapeBox(0F, 0F, 0F, 2, 1, 7, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F); // Box 18
		gunModel[43].setRotationPoint(-14F, -18.5F, -3.5F);

		gunModel[44].addShapeBox(0F, 0F, 0F, 2, 1, 9, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 19
		gunModel[44].setRotationPoint(-8F, -23.5F, -4.5F);

		gunModel[45].addShapeBox(0F, 0F, 0F, 20, 6, 1, 0F, 0F, 0F, 0F, 0F, 7F, 0F, 0F, 7F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, 0F, -7F, 0F, 0F, -7F, 0F, -0.5F, 0F, 0F); // Box 20
		gunModel[45].setRotationPoint(-8F, -25F, -4F);

		gunModel[46].addShapeBox(0F, 0F, 0F, 2, 1, 9, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F); // Box 21
		gunModel[46].setRotationPoint(-8F, -22.5F, -4.5F);

		gunModel[47].addBox(0F, 0F, 0F, 3, 6, 1, 0F); // Box 20
		gunModel[47].setRotationPoint(12F, -32F, -4F);

		gunModel[48].addBox(0F, 0F, 0F, 19, 1, 1, 0F); // Box 20
		gunModel[48].setRotationPoint(15F, -32F, -4F);

		gunModel[49].addBox(0F, 0F, 0F, 19, 1, 1, 0F); // Box 20
		gunModel[49].setRotationPoint(15F, -27F, -4F);

		gunModel[50].addBox(0F, 0F, 0F, 1, 4, 1, 0F); // Box 20
		gunModel[50].setRotationPoint(19F, -31F, -4F);

		gunModel[51].addBox(0F, 0F, 0F, 8, 6, 1, 0F); // Box 20
		gunModel[51].setRotationPoint(34F, -32F, -4F);

		gunModel[52].addShapeBox(0F, 0F, 0F, 2, 6, 1, 0F, 0F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, 0F, -0.5F, -0.5F, 0F, 0.5F, 0F, 0F, 0.5F, 0F, 0F, -0.5F, -0.5F, 0F); // Box 20
		gunModel[52].setRotationPoint(-10F, -25F, -4F);

		gunModel[53].addShapeBox(0F, 0F, 0F, 4, 5, 3, 0F, 0F, 0F, -1F, -2F, 0F, -1F, -2F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 40
		gunModel[53].setRotationPoint(79F, -31.5F, -1.5F);

		gunModel[54].addBox(0F, 0F, 0F, 8, 6, 1, 0F); // Box 20
		gunModel[54].setRotationPoint(34F, -32F, 3F);

		gunModel[55].addBox(0F, 0F, 0F, 3, 6, 1, 0F); // Box 20
		gunModel[55].setRotationPoint(12F, -32F, 3F);

		gunModel[56].addShapeBox(0F, 0F, 0F, 20, 6, 1, 0F, 0F, 0F, 0F, 0F, 7F, 0F, 0F, 7F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, 0F, -7F, 0F, 0F, -7F, 0F, -0.5F, 0F, 0F); // Box 20
		gunModel[56].setRotationPoint(-8F, -25F, 3F);

		gunModel[57].addShapeBox(0F, 0F, 0F, 2, 6, 1, 0F, 0F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, 0F, -0.5F, -0.5F, 0F, 0.5F, 0F, 0F, 0.5F, 0F, 0F, -0.5F, -0.5F, 0F); // Box 20
		gunModel[57].setRotationPoint(-10F, -25F, 3F);

		gunModel[58].addBox(0F, 0F, 0F, 19, 1, 6, 0F); // Box 20
		gunModel[58].setRotationPoint(12F, -27F, -3F);

		gunModel[59].addBox(0F, 0F, 0F, 2, 1, 6, 0F); // Box 20
		gunModel[59].setRotationPoint(36F, -27F, -3F);

		gunModel[60].addBox(0F, 0F, 0F, 3, 2, 5, 0F); // Box 52
		gunModel[60].setRotationPoint(32F, -28F, -2.5F);

		gunModel[61].addBox(0F, 0F, 0F, 1, 1, 5, 0F); // Box 53
		gunModel[61].setRotationPoint(33F, -29F, -2.5F);

		gunModel[62].addShapeBox(0F, 0F, 0F, 1, 1, 5, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 54
		gunModel[62].setRotationPoint(33F, -33F, -2.5F);

		gunModel[63].addBox(0F, 0F, 0F, 1, 3, 1, 0F); // Box 55
		gunModel[63].setRotationPoint(33F, -32F, -2.5F);

		gunModel[64].addBox(0F, 0F, 0F, 1, 3, 1, 0F); // Box 56
		gunModel[64].setRotationPoint(33F, -32F, 1.5F);

		gunModel[65].addBox(0F, 0F, 0F, 4, 2, 3, 0F); // Box 57
		gunModel[65].setRotationPoint(79F, -26.5F, -1.5F);

		gunModel[66].addBox(0F, 0F, 0F, 27, 4, 4, 0F); // Box 0
		gunModel[66].setRotationPoint(66F, -19F, -2F);

		gunModel[67].addBox(0F, 0F, 0F, 2, 5, 5, 0F); // Box 2
		gunModel[67].setRotationPoint(72F, -19.5F, -2.5F);

		gunModel[68].addBox(0F, 0F, 0F, 10, 5, 5, 0F); // Box 3
		gunModel[68].setRotationPoint(86F, -25F, -2.5F);

		gunModel[69].addBox(0F, 0F, 0F, 1, 4, 1, 0F); // Box 6
		gunModel[69].setRotationPoint(24F, -31F, -4F);

		gunModel[70].addBox(0F, 0F, 0F, 1, 4, 1, 0F); // Box 8
		gunModel[70].setRotationPoint(29F, -31F, -4F);

		gunModel[71].addBox(0F, 0F, 0F, 1, 4, 1, 0F); // Box 11
		gunModel[71].setRotationPoint(19F, -31F, 3F);

		gunModel[72].addBox(0F, 0F, 0F, 19, 1, 1, 0F); // Box 12
		gunModel[72].setRotationPoint(15F, -27F, 3F);

		gunModel[73].addBox(0F, 0F, 0F, 1, 4, 1, 0F); // Box 13
		gunModel[73].setRotationPoint(24F, -31F, 3F);

		gunModel[74].addBox(0F, 0F, 0F, 19, 1, 1, 0F); // Box 14
		gunModel[74].setRotationPoint(15F, -32F, 3F);

		gunModel[75].addBox(0F, 0F, 0F, 1, 4, 1, 0F); // Box 15
		gunModel[75].setRotationPoint(29F, -31F, 3F);

		gunModel[76].addBox(0F, 0F, 0F, 1, 2, 5, 0F); // Box 16
		gunModel[76].setRotationPoint(73F, -14.5F, -2.5F);

		gunModel[77].addBox(0F, 0F, 0F, 2, 5, 3, 0F); // Box 19
		gunModel[77].setRotationPoint(3F, -12.5F, -1.5F);

		gunModel[78].addBox(0F, 0F, 0F, 1, 5, 3, 0F); // Box 20
		gunModel[78].setRotationPoint(11F, -12.5F, -1.5F);

		gunModel[79].addBox(0F, 0F, 0F, 1, 2, 2, 0F); // Box 21
		gunModel[79].setRotationPoint(6F, -12.5F, -1F);

		gunModel[80].addShapeBox(0F, 0F, 0F, 1, 2, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F); // Box 22
		gunModel[80].setRotationPoint(6F, -10.5F, -1F);

		gunModel[81].addShapeBox(0F, 0F, 0F, 8, 1, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F); // Box 23
		gunModel[81].setRotationPoint(4F, -7.5F, -1.5F);

		gunModel[82].addShapeBox(0F, 0F, 0F, 6, 5, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, -1F, 0F, -1F, -1F, 0F, 0F, 0F, 0F); // Box 24
		gunModel[82].setRotationPoint(12F, -12.5F, -1.5F);


		ammoModel = new ModelRendererTurbo[2];
		ammoModel[0] = new ModelRendererTurbo(this, 1, 1, textureX, textureY); // shell1-2
		ammoModel[1] = new ModelRendererTurbo(this, 1, 1, textureX, textureY); // Box 1

		ammoModel[0].addShapeBox(0F, 0F, 0F, 10, 2, 4, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // shell1-2
		ammoModel[0].setRotationPoint(19F, -17.5F, -2F);

		ammoModel[1].addShapeBox(0F, 0F, 0F, 10, 2, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 1
		ammoModel[1].setRotationPoint(19F, -15.5F, -2F);


		pumpModel = new ModelRendererTurbo[13];
		pumpModel[0] = new ModelRendererTurbo(this, 80, 24, textureX, textureY); // Box 14
		pumpModel[1] = new ModelRendererTurbo(this, 80, 20, textureX, textureY); // Box 14
		pumpModel[2] = new ModelRendererTurbo(this, 168, 118, textureX, textureY); // Box 14
		pumpModel[3] = new ModelRendererTurbo(this, 231, 103, textureX, textureY); // Box 14
		pumpModel[4] = new ModelRendererTurbo(this, 173, 103, textureX, textureY); // Box 14
		pumpModel[5] = new ModelRendererTurbo(this, 200, 103, textureX, textureY); // Box 14
		pumpModel[6] = new ModelRendererTurbo(this, 146, 103, textureX, textureY); // Box 14
		pumpModel[7] = new ModelRendererTurbo(this, 80, 103, textureX, textureY); // Box 14
		pumpModel[8] = new ModelRendererTurbo(this, 121, 103, textureX, textureY); // Box 14
		pumpModel[9] = new ModelRendererTurbo(this, 143, 117, textureX, textureY); // Box 14
		pumpModel[10] = new ModelRendererTurbo(this, 197, 124, textureX, textureY); // Box 14
		pumpModel[11] = new ModelRendererTurbo(this, 80, 118, textureX, textureY); // Box 14
		pumpModel[12] = new ModelRendererTurbo(this, 61, 17, textureX, textureY); // Box 25

		pumpModel[0].addBox(0F, 0F, 0F, 11, 4, 2, 0F); // Box 14
		pumpModel[0].setRotationPoint(14F, -24F, -2.5F);

		pumpModel[1].addShapeBox(0F, 0F, 0F, 11, 1, 2, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 14
		pumpModel[1].setRotationPoint(14F, -25F, -2.5F);

		pumpModel[2].addShapeBox(0F, 0F, 0F, 4, 8, 10, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 14
		pumpModel[2].setRotationPoint(63F, -22.5F, -5F);

		pumpModel[3].addShapeBox(0F, 0F, 0F, 4, 3, 10, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F); // Box 14
		pumpModel[3].setRotationPoint(63F, -14.5F, -5F);

		pumpModel[4].addShapeBox(0F, 0F, 0F, 3, 3, 10, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 2F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 2F, -2F); // Box 14
		pumpModel[4].setRotationPoint(60F, -14.5F, -5F);

		pumpModel[5].addShapeBox(0F, 0F, 0F, 5, 3, 10, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F); // Box 14
		pumpModel[5].setRotationPoint(55F, -12.5F, -5F);

		pumpModel[6].addShapeBox(0F, 0F, 0F, 3, 3, 10, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 2F, -2F, 0F, 2F, -2F, 0F, 0F, -2F); // Box 14
		pumpModel[6].setRotationPoint(52F, -14.5F, -5F);

		pumpModel[7].addShapeBox(0F, 0F, 0F, 10, 3, 10, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F); // Box 14
		pumpModel[7].setRotationPoint(42F, -14.5F, -5F);

		pumpModel[8].addShapeBox(0F, 0F, 0F, 2, 3, 10, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F); // Box 14
		pumpModel[8].setRotationPoint(40F, -13.5F, -5F);

		pumpModel[9].addBox(0F, 0F, 0F, 2, 9, 10, 0F); // Box 14
		pumpModel[9].setRotationPoint(40F, -22.5F, -5F);

		pumpModel[10].addShapeBox(0F, 0F, 0F, 11, 2, 10, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F); // Box 14
		pumpModel[10].setRotationPoint(52F, -14.5F, -5F);

		pumpModel[11].addBox(0F, 0F, 0F, 21, 8, 10, 0F); // Box 14
		pumpModel[11].setRotationPoint(42F, -22.5F, -5F);

		pumpModel[12].addBox(0F, 0F, 0F, 2, 2, 5, 0F); // Box 25
		pumpModel[12].setRotationPoint(23F, -22.5F, -7.5F);
		
		casingAttachPoint = new Vector3f(15F /16F, 23.5F /16F, 2F /16F);

		animationType = EnumAnimationType.SHOTGUN;

		numBulletsInReloadAnimation = 6;
		tiltGunTime = 0.200F;
		unloadClipTime = 0.0F;
		loadClipTime = 0.600F;
		untiltGunTime = 0.200F;

		pumpDelay = 10;
		pumpTime = 7;
		pumpDelayAfterReload = 110;
		pumpHandleDistance = 1F;

		RotateSlideDistance = -20F;
		RecoilSlideDistance = 0.25F;

		casingDelay = 12;
		casingAnimTime = 6;
		caseScale = 0.2F;

		flipAll();
		translateAll(0F, 0F, 0F);
	}
}