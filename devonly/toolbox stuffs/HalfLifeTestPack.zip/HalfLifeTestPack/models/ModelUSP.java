package com.flansmod.client.model.hltp;

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelUSP extends ModelGun
{
	int textureX = 512;
	int textureY = 256;

	public ModelUSP()
	{
		gunModel = new ModelRendererTurbo[30];
		gunModel[0] = new ModelRendererTurbo(this, 89, 1, textureX, textureY); // Box 5
		gunModel[1] = new ModelRendererTurbo(this, 31, 37, textureX, textureY); // Box 6
		gunModel[2] = new ModelRendererTurbo(this, 30, 28, textureX, textureY); // Box 19
		gunModel[3] = new ModelRendererTurbo(this, 1, 10, textureX, textureY); // Box 20
		gunModel[4] = new ModelRendererTurbo(this, 14, 84, textureX, textureY); // Box 22
		gunModel[5] = new ModelRendererTurbo(this, 122, 18, textureX, textureY); // Box 25
		gunModel[6] = new ModelRendererTurbo(this, 1, 37, textureX, textureY); // Box 26
		gunModel[7] = new ModelRendererTurbo(this, 102, 12, textureX, textureY); // Box 27
		gunModel[8] = new ModelRendererTurbo(this, 133, 16, textureX, textureY); // Box 30
		gunModel[9] = new ModelRendererTurbo(this, 133, 22, textureX, textureY); // Box 31
		gunModel[10] = new ModelRendererTurbo(this, 48, 2, textureX, textureY); // Box 0
		gunModel[11] = new ModelRendererTurbo(this, 28, 67, textureX, textureY); // Box 35
		gunModel[12] = new ModelRendererTurbo(this, 24, 51, textureX, textureY); // Box 36
		gunModel[13] = new ModelRendererTurbo(this, 18, 37, textureX, textureY); // Box 37
		gunModel[14] = new ModelRendererTurbo(this, 93, 9, textureX, textureY); // Box 1
		gunModel[15] = new ModelRendererTurbo(this, 1, 25, textureX, textureY); // Box 2
		gunModel[16] = new ModelRendererTurbo(this, 24, 74, textureX, textureY); // Box 4
		gunModel[17] = new ModelRendererTurbo(this, 113, 29, textureX, textureY); // Box 5
		gunModel[18] = new ModelRendererTurbo(this, 88, 45, textureX, textureY); // Box 11
		gunModel[19] = new ModelRendererTurbo(this, 48, 66, textureX, textureY); // Box 16
		gunModel[20] = new ModelRendererTurbo(this, 48, 84, textureX, textureY); // Box 17
		gunModel[21] = new ModelRendererTurbo(this, 77, 66, textureX, textureY); // Box 18
		gunModel[22] = new ModelRendererTurbo(this, 77, 75, textureX, textureY); // Box 19
		gunModel[23] = new ModelRendererTurbo(this, 48, 75, textureX, textureY); // Box 20
		gunModel[24] = new ModelRendererTurbo(this, 77, 84, textureX, textureY); // Box 21
		gunModel[25] = new ModelRendererTurbo(this, 92, 75, textureX, textureY); // Box 22
		gunModel[26] = new ModelRendererTurbo(this, 48, 52, textureX, textureY); // Box 24
		gunModel[27] = new ModelRendererTurbo(this, 65, 46, textureX, textureY); // Box 27
		gunModel[28] = new ModelRendererTurbo(this, 83, 59, textureX, textureY); // Box 52
		gunModel[29] = new ModelRendererTurbo(this, 83, 63, textureX, textureY); // Box 53

		gunModel[0].addBox(0F, 0F, 0F, 18, 2, 5, 0F); // Box 5
		gunModel[0].setRotationPoint(-4F, -22F, -2.5F);

		gunModel[1].addShapeBox(0F, 0F, 0F, 1, 3, 5, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 6
		gunModel[1].setRotationPoint(-4F, -20F, -2.5F);

		gunModel[2].addBox(0F, 0F, 0F, 1, 3, 5, 0F); // Box 19
		gunModel[2].setRotationPoint(-4F, -17F, -2.5F);

		gunModel[3].addShapeBox(0F, 0F, 0F, 11, 9, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 3F, 0F, 0F); // Box 20
		gunModel[3].setRotationPoint(-4F, -14F, -2.5F);

		gunModel[4].addBox(0F, 0F, 0F, 8, 1, 5, 0F); // Box 22
		gunModel[4].setRotationPoint(-4F, -5F, -2.5F);

		gunModel[5].addBox(0F, 0F, 0F, 1, 5, 4, 0F); // Box 25
		gunModel[5].setRotationPoint(16F, -20F, -2F);

		gunModel[6].addShapeBox(0F, 0F, 0F, 3, 6, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F); // Box 26
		gunModel[6].setRotationPoint(6F, -20F, -2.5F);

		gunModel[7].addBox(0F, 0F, 0F, 9, 1, 4, 0F); // Box 27
		gunModel[7].setRotationPoint(6F, -15F, -2F);

		gunModel[8].addBox(0F, 0F, 0F, 2, 2, 3, 0F); // Box 30
		gunModel[8].setRotationPoint(10F, -20F, -1.5F);

		gunModel[9].addShapeBox(0F, 0F, 0F, 2, 2, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F); // Box 31
		gunModel[9].setRotationPoint(10F, -18F, -1.5F);

		gunModel[10].addBox(0F, 0F, 0F, 16, 2, 4, 0F); // Box 0
		gunModel[10].setRotationPoint(14F, -22F, -2F);

		gunModel[11].addShapeBox(0F, 0F, 0F, 1, 1, 5, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F); // Box 35
		gunModel[11].setRotationPoint(4F, -5F, -2.5F);

		gunModel[12].addShapeBox(0F, 0F, 0F, 1, 9, 5, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 3F, 0F, 0F, -3F, 0F, -1F, -3F, 0F, -1F, 3F, 0F, 0F); // Box 36
		gunModel[12].setRotationPoint(7F, -14F, -2.5F);

		gunModel[13].addShapeBox(0F, 0F, 0F, 1, 6, 5, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 2F, 0F, 0F, -2F, 0F, -1F, -2F, 0F, -1F, 2F, 0F, 0F); // Box 37
		gunModel[13].setRotationPoint(9F, -20F, -2.5F);

		gunModel[14].addShapeBox(0F, 0F, 0F, 2, 1, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F); // Box 1
		gunModel[14].setRotationPoint(15F, -15F, -2F);

		gunModel[15].addBox(0F, 0F, 0F, 9, 6, 5, 0F); // Box 2
		gunModel[15].setRotationPoint(-3F, -20F, -2.5F);

		gunModel[16].addShapeBox(0F, 0F, 0F, 3, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F); // Box 4
		gunModel[16].setRotationPoint(-7F, -5F, -2.5F);

		gunModel[17].addShapeBox(0F, 0F, 0F, 2, 2, 5, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 5
		gunModel[17].setRotationPoint(-6F, -22F, -2.5F);

		gunModel[18].addBox(0F, 0F, 0F, 7, 2, 4, 0F); // Box 11
		gunModel[18].setRotationPoint(11F, -25.5F, -2F);

		gunModel[19].addShapeBox(0F, 0F, 0F, 8, 2, 6, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 16
		gunModel[19].setRotationPoint(30F, -27F, -3F);

		gunModel[20].addShapeBox(0F, 0F, 0F, 8, 2, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F); // Box 17
		gunModel[20].setRotationPoint(30F, -23F, -3F);

		gunModel[21].addShapeBox(0F, 0F, 0F, 13, 2, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F); // Box 18
		gunModel[21].setRotationPoint(18F, -21F, -3F);

		gunModel[22].addShapeBox(0F, 0F, 0F, 1, 2, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F); // Box 19
		gunModel[22].setRotationPoint(36F, -21F, -3F);

		gunModel[23].addBox(0F, 0F, 0F, 8, 2, 6, 0F); // Box 20
		gunModel[23].setRotationPoint(30F, -25F, -3F);

		gunModel[24].addShapeBox(0F, 0F, 0F, 1, 2, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F); // Box 21
		gunModel[24].setRotationPoint(34F, -21F, -3F);

		gunModel[25].addShapeBox(0F, 0F, 0F, 1, 2, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F); // Box 22
		gunModel[25].setRotationPoint(32F, -21F, -3F);

		gunModel[26].addBox(0F, 0F, 0F, 18, 3, 3, 0F); // Box 24
		gunModel[26].setRotationPoint(21F, -26.5F, -1.5F);

		gunModel[27].addShapeBox(0F, 0F, 0F, 7, 1, 4, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 27
		gunModel[27].setRotationPoint(11F, -26.5F, -2F);

		gunModel[28].addBox(0F, 0F, 0F, 5, 2, 1, 0F); // Box 52
		gunModel[28].setRotationPoint(-4F, -22F, 2.5F);

		gunModel[29].addBox(0F, 0F, 0F, 8, 1, 1, 0F); // Box 53
		gunModel[29].setRotationPoint(5F, -21.5F, 2F);


		ammoModel = new ModelRendererTurbo[5];
		ammoModel[0] = new ModelRendererTurbo(this, 1, 49, textureX, textureY); // Box 25
		ammoModel[1] = new ModelRendererTurbo(this, 1, 82, textureX, textureY); // Box 26
		ammoModel[2] = new ModelRendererTurbo(this, 1, 66, textureX, textureY); // Box 27
		ammoModel[3] = new ModelRendererTurbo(this, 1, 74, textureX, textureY); // Box 34
		ammoModel[4] = new ModelRendererTurbo(this, 32, 48, textureX, textureY); // Box 39

		ammoModel[0].addShapeBox(0F, 0F, 0F, 7, 12, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 4F, 0F, 0F, -4F, 0F, 0F, -4F, 0F, 0F, 4F, 0F, 0F); // Box 25
		ammoModel[0].setRotationPoint(0F, -16F, -2F);

		ammoModel[1].addBox(0F, 0F, 0F, 6, 1, 2, 0F); // Box 26
		ammoModel[1].setRotationPoint(1F, -20F, -1F);

		ammoModel[2].addShapeBox(0F, 0F, 0F, 8, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F); // Box 27
		ammoModel[2].setRotationPoint(-4F, -4F, -2.5F);

		ammoModel[3].addShapeBox(0F, 0F, 0F, 7, 3, 4, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F); // Box 34
		ammoModel[3].setRotationPoint(1F, -19F, -2F);

		ammoModel[4].addShapeBox(0F, 0F, 0F, 1, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F); // Box 39
		ammoModel[4].setRotationPoint(4F, -4F, -2.5F);


		slideModel = new ModelRendererTurbo[16];
		slideModel[0] = new ModelRendererTurbo(this, 48, 18, textureX, textureY); // Box 0
		slideModel[1] = new ModelRendererTurbo(this, 1, 1, textureX, textureY); // Box 18
		slideModel[2] = new ModelRendererTurbo(this, 8, 1, textureX, textureY); // Box 23
		slideModel[3] = new ModelRendererTurbo(this, 8, 1, textureX, textureY); // Box 24
		slideModel[4] = new ModelRendererTurbo(this, 98, 28, textureX, textureY); // Box 32
		slideModel[5] = new ModelRendererTurbo(this, 48, 43, textureX, textureY); // Box 9
		slideModel[6] = new ModelRendererTurbo(this, 48, 37, textureX, textureY); // Box 10
		slideModel[7] = new ModelRendererTurbo(this, 59, 37, textureX, textureY); // Box 17
		slideModel[8] = new ModelRendererTurbo(this, 48, 9, textureX, textureY); // Box 6
		slideModel[9] = new ModelRendererTurbo(this, 48, 59, textureX, textureY); // Box 7
		slideModel[10] = new ModelRendererTurbo(this, 87, 20, textureX, textureY); // Box 8
		slideModel[11] = new ModelRendererTurbo(this, 90, 39, textureX, textureY); // Box 9
		slideModel[12] = new ModelRendererTurbo(this, 48, 28, textureX, textureY); // Box 13
		slideModel[13] = new ModelRendererTurbo(this, 81, 29, textureX, textureY); // Box 14
		slideModel[14] = new ModelRendererTurbo(this, 1, 4, textureX, textureY); // Box 15
		slideModel[15] = new ModelRendererTurbo(this, 109, 39, textureX, textureY); // Box 28

		slideModel[0].addBox(0F, 0F, 0F, 13, 3, 6, 0F); // Box 0
		slideModel[0].setRotationPoint(-2F, -25F, -3F);

		slideModel[1].addBox(0F, 0F, 0F, 2, 1, 1, 0F); // Box 18
		slideModel[1].setRotationPoint(28F, -28F, -0.5F);

		slideModel[2].addBox(0F, 0F, 0F, 4, 1, 1, 0F); // Box 23
		slideModel[2].setRotationPoint(-2F, -28F, -2F);

		slideModel[3].addBox(0F, 0F, 0F, 4, 1, 1, 0F); // Box 24
		slideModel[3].setRotationPoint(-2F, -28F, 1F);

		slideModel[4].addShapeBox(0F, 0F, 0F, 1, 2, 6, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 32
		slideModel[4].setRotationPoint(-2F, -27F, -3F);

		slideModel[5].addShapeBox(0F, 0F, 0F, 2, 2, 6, 0F, -1F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, -1F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 9
		slideModel[5].setRotationPoint(-4F, -27F, -3F);

		slideModel[6].addShapeBox(0F, 0F, 0F, 3, 3, 2, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 10
		slideModel[6].setRotationPoint(-5F, -25F, -3F);

		slideModel[7].addShapeBox(0F, 0F, 0F, 3, 3, 2, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 17
		slideModel[7].setRotationPoint(-5F, -25F, 1F);

		slideModel[8].addBox(0F, 0F, 0F, 19, 2, 6, 0F); // Box 6
		slideModel[8].setRotationPoint(11F, -24F, -3F);

		slideModel[9].addBox(0F, 0F, 0F, 12, 1, 5, 0F); // Box 7
		slideModel[9].setRotationPoint(18F, -25F, -2.5F);

		slideModel[10].addShapeBox(0F, 0F, 0F, 12, 2, 5, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 8
		slideModel[10].setRotationPoint(18F, -27F, -2.5F);

		slideModel[11].addBox(0F, 0F, 0F, 7, 1, 2, 0F); // Box 9
		slideModel[11].setRotationPoint(11F, -25F, 0.5F);

		slideModel[12].addShapeBox(0F, 0F, 0F, 10, 2, 6, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 13
		slideModel[12].setRotationPoint(1F, -27F, -3F);

		slideModel[13].addShapeBox(0F, 0F, 0F, 2, 1, 6, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 14
		slideModel[13].setRotationPoint(-1F, -26F, -3F);

		slideModel[14].addBox(0F, 0F, 0F, 2, 1, 4, 0F); // Box 15
		slideModel[14].setRotationPoint(-1F, -27F, -2F);

		slideModel[15].addShapeBox(0F, 0F, 0F, 7, 1, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 28
		slideModel[15].setRotationPoint(11F, -26F, 0.5F);


		hammerModel = new ModelRendererTurbo[2];
		hammerModel[0] = new ModelRendererTurbo(this, 70, 38, textureX, textureY); // Box 25
		hammerModel[1] = new ModelRendererTurbo(this, 81, 38, textureX, textureY); // Box 26

		hammerModel[0].addShapeBox(0F, 0F, 0F, 3, 2, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 25
		hammerModel[0].setRotationPoint(-5F, -24F, -1F);

		hammerModel[1].addShapeBox(0F, 0F, 0F, 2, 2, 2, 0F, 0F, 1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F); // Box 26
		hammerModel[1].setRotationPoint(-7F, -24F, -1F);
		
		animationType = EnumAnimationType.PISTOL_CLIP;
		gunSlideDistance = 0.8F;

		casingAnimTime = 8;
		slideLockOnEmpty = true;
		RotateSlideDistance = -20F;

		flipAll();
		translateAll(0F, 0F, 0F);
	}
}