package com.flansmod.client.model.hltp;

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelGlock extends ModelGun
{
	int textureX = 512;
	int textureY = 256;

	public ModelGlock()
	{
		gunModel = new ModelRendererTurbo[16];
		gunModel[0] = new ModelRendererTurbo(this, 1, 10, textureX, textureY); // Box 3
		gunModel[1] = new ModelRendererTurbo(this, 32, 1, textureX, textureY); // Box 5
		gunModel[2] = new ModelRendererTurbo(this, 132, 39, textureX, textureY); // Box 6
		gunModel[3] = new ModelRendererTurbo(this, 69, 32, textureX, textureY); // Box 9
		gunModel[4] = new ModelRendererTurbo(this, 97, 3, textureX, textureY); // Box 16
		gunModel[5] = new ModelRendererTurbo(this, 32, 30, textureX, textureY); // Box 19
		gunModel[6] = new ModelRendererTurbo(this, 32, 39, textureX, textureY); // Box 20
		gunModel[7] = new ModelRendererTurbo(this, 75, 21, textureX, textureY); // Box 22
		gunModel[8] = new ModelRendererTurbo(this, 32, 21, textureX, textureY); // Box 24
		gunModel[9] = new ModelRendererTurbo(this, 117, 27, textureX, textureY); // Box 25
		gunModel[10] = new ModelRendererTurbo(this, 117, 38, textureX, textureY); // Box 26
		gunModel[11] = new ModelRendererTurbo(this, 110, 19, textureX, textureY); // Box 27
		gunModel[12] = new ModelRendererTurbo(this, 132, 48, textureX, textureY); // Box 28
		gunModel[13] = new ModelRendererTurbo(this, 98, 31, textureX, textureY); // Box 29
		gunModel[14] = new ModelRendererTurbo(this, 68, 20, textureX, textureY); // Box 30
		gunModel[15] = new ModelRendererTurbo(this, 57, 20, textureX, textureY); // Box 31

		gunModel[0].addBox(0F, 0F, 0F, 6, 3, 4, 0F); // Box 3
		gunModel[0].setRotationPoint(9F, -26.5F, -2F);

		gunModel[1].addBox(0F, 0F, 0F, 26, 2, 6, 0F); // Box 5
		gunModel[1].setRotationPoint(-6F, -22F, -3F);

		gunModel[2].addShapeBox(0F, 0F, 0F, 1, 2, 6, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 6
		gunModel[2].setRotationPoint(-4F, -20F, -3F);

		gunModel[3].addBox(0F, 0F, 0F, 10, 2, 4, 0F); // Box 9
		gunModel[3].setRotationPoint(20F, -22F, -2F);

		gunModel[4].addBox(0F, 0F, 0F, 10, 3, 3, 0F); // Box 16
		gunModel[4].setRotationPoint(21F, -26F, -1.5F);

		gunModel[5].addBox(0F, 0F, 0F, 10, 2, 6, 0F); // Box 19
		gunModel[5].setRotationPoint(-4F, -18F, -3F);

		gunModel[6].addShapeBox(0F, 0F, 0F, 11, 10, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 4F, 0F, 0F, -4F, 0F, 0F, -4F, 0F, 0F, 4F, 0F, 0F); // Box 20
		gunModel[6].setRotationPoint(-4F, -16F, -3F);

		gunModel[7].addBox(0F, 0F, 0F, 11, 3, 6, 0F); // Box 22
		gunModel[7].setRotationPoint(-8F, -6F, -3F);

		gunModel[8].addBox(0F, 0F, 0F, 9, 2, 6, 0F); // Box 24
		gunModel[8].setRotationPoint(-3F, -20F, -3F);

		gunModel[9].addBox(0F, 0F, 0F, 2, 5, 5, 0F); // Box 25
		gunModel[9].setRotationPoint(15F, -20F, -2.5F);

		gunModel[10].addShapeBox(0F, 0F, 0F, 1, 4, 6, 0F, 0F, 0F, 0F, 2F, 0F, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 26
		gunModel[10].setRotationPoint(6F, -20F, -3F);

		gunModel[11].addBox(0F, 0F, 0F, 7, 2, 5, 0F); // Box 27
		gunModel[11].setRotationPoint(8F, -15F, -2.5F);

		gunModel[12].addShapeBox(0F, 0F, 0F, 2, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F); // Box 28
		gunModel[12].setRotationPoint(6F, -15F, -2.5F);

		gunModel[13].addShapeBox(0F, 0F, 0F, 2, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, 0F, 0F, 0F); // Box 29
		gunModel[13].setRotationPoint(15F, -15F, -2.5F);

		gunModel[14].addBox(0F, 0F, 0F, 2, 2, 3, 0F); // Box 30
		gunModel[14].setRotationPoint(9F, -20F, -1.5F);

		gunModel[15].addShapeBox(0F, 0F, 0F, 2, 2, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F); // Box 31
		gunModel[15].setRotationPoint(9F, -18F, -1.5F);


		ammoModel = new ModelRendererTurbo[3];
		ammoModel[0] = new ModelRendererTurbo(this, 1, 18, textureX, textureY); // Box 25
		ammoModel[1] = new ModelRendererTurbo(this, 1, 45, textureX, textureY); // Box 26
		ammoModel[2] = new ModelRendererTurbo(this, 1, 38, textureX, textureY); // Box 27

		ammoModel[0].addShapeBox(0F, 0F, 0F, 8, 15, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 4F, 0F, 0F, -4F, 0F, 0F, -4F, 0F, 0F, 4F, 0F, 0F); // Box 25
		ammoModel[0].setRotationPoint(-2F, -18F, -2F);

		ammoModel[1].addBox(0F, 0F, 0F, 6, 1, 2, 0F); // Box 26
		ammoModel[1].setRotationPoint(-1F, -19F, -1F);

		ammoModel[2].addBox(0F, 0F, 0F, 9, 1, 5, 0F); // Box 27
		ammoModel[2].setRotationPoint(-6.5F, -3F, -2.5F);


		slideModel = new ModelRendererTurbo[12];
		slideModel[0] = new ModelRendererTurbo(this, 32, 10, textureX, textureY); // Box 0
		slideModel[1] = new ModelRendererTurbo(this, 124, 10, textureX, textureY); // Box 1
		slideModel[2] = new ModelRendererTurbo(this, 67, 48, textureX, textureY); // Box 2
		slideModel[3] = new ModelRendererTurbo(this, 73, 10, textureX, textureY); // Box 4
		slideModel[4] = new ModelRendererTurbo(this, 1, 4, textureX, textureY); // Box 15
		slideModel[5] = new ModelRendererTurbo(this, 1, 1, textureX, textureY); // Box 18
		slideModel[6] = new ModelRendererTurbo(this, 12, 1, textureX, textureY); // Box 23
		slideModel[7] = new ModelRendererTurbo(this, 12, 1, textureX, textureY); // Box 24
		slideModel[8] = new ModelRendererTurbo(this, 102, 39, textureX, textureY); // Box 20
		slideModel[9] = new ModelRendererTurbo(this, 90, 49, textureX, textureY); // Box 21
		slideModel[10] = new ModelRendererTurbo(this, 114, 16, textureX, textureY); // Box 22
		slideModel[11] = new ModelRendererTurbo(this, 69, 39, textureX, textureY); // Box 32

		slideModel[0].addBox(0F, 0F, 0F, 15, 4, 5, 0F); // Box 0
		slideModel[0].setRotationPoint(-6F, -26F, -2.5F);

		slideModel[1].addBox(0F, 0F, 0F, 6, 2, 1, 0F); // Box 1
		slideModel[1].setRotationPoint(9F, -26F, 1.5F);

		slideModel[2].addBox(0F, 0F, 0F, 6, 2, 5, 0F); // Box 2
		slideModel[2].setRotationPoint(9F, -24F, -2.5F);

		slideModel[3].addBox(0F, 0F, 0F, 15, 4, 5, 0F); // Box 4
		slideModel[3].setRotationPoint(15F, -26F, -2.5F);

		slideModel[4].addBox(0F, 0F, 0F, 2, 1, 4, 0F); // Box 15
		slideModel[4].setRotationPoint(-4F, -27F, -2F);

		slideModel[5].addBox(0F, 0F, 0F, 2, 1, 1, 0F); // Box 18
		slideModel[5].setRotationPoint(28F, -28F, -0.5F);

		slideModel[6].addBox(0F, 0F, 0F, 2, 1, 1, 0F); // Box 23
		slideModel[6].setRotationPoint(-4F, -28F, -2F);

		slideModel[7].addBox(0F, 0F, 0F, 2, 1, 1, 0F); // Box 24
		slideModel[7].setRotationPoint(-4F, -28F, 1F);

		slideModel[8].addShapeBox(0F, 0F, 0F, 2, 1, 5, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 20
		slideModel[8].setRotationPoint(-6F, -27F, -2.5F);

		slideModel[9].addShapeBox(0F, 0F, 0F, 15, 1, 5, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 21
		slideModel[9].setRotationPoint(15F, -27F, -2.5F);

		slideModel[10].addShapeBox(0F, 0F, 0F, 6, 1, 1, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 22
		slideModel[10].setRotationPoint(9F, -27F, 1.5F);

		slideModel[11].addShapeBox(0F, 0F, 0F, 11, 1, 5, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 32
		slideModel[11].setRotationPoint(-2F, -27F, -2.5F);
		
		animationType = EnumAnimationType.PISTOL_CLIP;
		gunSlideDistance = 0.8F;

		casingAnimTime = 8;
		slideLockOnEmpty = true;
		RotateSlideDistance = -15F;

		flipAll();
		translateAll(0F, 0F, 0F);
	}
}