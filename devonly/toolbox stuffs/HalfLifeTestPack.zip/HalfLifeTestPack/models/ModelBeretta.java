package com.flansmod.client.model.hltp;

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelBeretta extends ModelGun
{
	int textureX = 512;
	int textureY = 256;

	public ModelBeretta()
	{
		gunModel = new ModelRendererTurbo[33];
		gunModel[0] = new ModelRendererTurbo(this, 75, 1, textureX, textureY); // Box 5
		gunModel[1] = new ModelRendererTurbo(this, 135, 41, textureX, textureY); // Box 6
		gunModel[2] = new ModelRendererTurbo(this, 116, 2, textureX, textureY); // Box 16
		gunModel[3] = new ModelRendererTurbo(this, 32, 26, textureX, textureY); // Box 19
		gunModel[4] = new ModelRendererTurbo(this, 32, 34, textureX, textureY); // Box 20
		gunModel[5] = new ModelRendererTurbo(this, 32, 49, textureX, textureY); // Box 22
		gunModel[6] = new ModelRendererTurbo(this, 129, 29, textureX, textureY); // Box 25
		gunModel[7] = new ModelRendererTurbo(this, 78, 29, textureX, textureY); // Box 26
		gunModel[8] = new ModelRendererTurbo(this, 121, 12, textureX, textureY); // Box 27
		gunModel[9] = new ModelRendererTurbo(this, 93, 58, textureX, textureY); // Box 28
		gunModel[10] = new ModelRendererTurbo(this, 116, 23, textureX, textureY); // Box 29
		gunModel[11] = new ModelRendererTurbo(this, 73, 19, textureX, textureY); // Box 30
		gunModel[12] = new ModelRendererTurbo(this, 62, 19, textureX, textureY); // Box 31
		gunModel[13] = new ModelRendererTurbo(this, 32, 2, textureX, textureY); // Box 0
		gunModel[14] = new ModelRendererTurbo(this, 65, 52, textureX, textureY); // Box 2
		gunModel[15] = new ModelRendererTurbo(this, 124, 50, textureX, textureY); // Box 11
		gunModel[16] = new ModelRendererTurbo(this, 109, 50, textureX, textureY); // Box 12
		gunModel[17] = new ModelRendererTurbo(this, 32, 58, textureX, textureY); // Box 18
		gunModel[18] = new ModelRendererTurbo(this, 45, 25, textureX, textureY); // Box 19
		gunModel[19] = new ModelRendererTurbo(this, 63, 64, textureX, textureY); // Box 20
		gunModel[20] = new ModelRendererTurbo(this, 125, 57, textureX, textureY); // Box 21
		gunModel[21] = new ModelRendererTurbo(this, 91, 40, textureX, textureY); // Box 23
		gunModel[22] = new ModelRendererTurbo(this, 106, 57, textureX, textureY); // Box 24
		gunModel[23] = new ModelRendererTurbo(this, 82, 65, textureX, textureY); // Box 25
		gunModel[24] = new ModelRendererTurbo(this, 10, 9, textureX, textureY); // Box 28
		gunModel[25] = new ModelRendererTurbo(this, 91, 30, textureX, textureY); // Box 29
		gunModel[26] = new ModelRendererTurbo(this, 21, 5, textureX, textureY); // Box 31
		gunModel[27] = new ModelRendererTurbo(this, 21, 9, textureX, textureY); // Box 32
		gunModel[28] = new ModelRendererTurbo(this, 21, 9, textureX, textureY); // Box 33
		gunModel[29] = new ModelRendererTurbo(this, 116, 30, textureX, textureY); // Box 35
		gunModel[30] = new ModelRendererTurbo(this, 65, 34, textureX, textureY); // Box 36
		gunModel[31] = new ModelRendererTurbo(this, 78, 39, textureX, textureY); // Box 37
		gunModel[32] = new ModelRendererTurbo(this, 108, 11, textureX, textureY); // Box 38

		gunModel[0].addBox(0F, 0F, 0F, 15, 2, 5, 0F); // Box 5
		gunModel[0].setRotationPoint(-6F, -22F, -2.5F);

		gunModel[1].addShapeBox(0F, 0F, 0F, 1, 2, 5, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 6
		gunModel[1].setRotationPoint(-4F, -20F, -2.5F);

		gunModel[2].addBox(0F, 0F, 0F, 20, 3, 3, 0F); // Box 16
		gunModel[2].setRotationPoint(11F, -26.5F, -1.5F);

		gunModel[3].addBox(0F, 0F, 0F, 1, 2, 5, 0F); // Box 19
		gunModel[3].setRotationPoint(-4F, -18F, -2.5F);

		gunModel[4].addShapeBox(0F, 0F, 0F, 11, 9, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 3F, 0F, 0F); // Box 20
		gunModel[4].setRotationPoint(-4F, -16F, -2.5F);

		gunModel[5].addBox(0F, 0F, 0F, 11, 3, 5, 0F); // Box 22
		gunModel[5].setRotationPoint(-7F, -7F, -2.5F);

		gunModel[6].addBox(0F, 0F, 0F, 2, 5, 4, 0F); // Box 25
		gunModel[6].setRotationPoint(15F, -20F, -2F);

		gunModel[7].addShapeBox(0F, 0F, 0F, 1, 4, 5, 0F, 0F, 0F, 0F, 2F, 0F, 0F, 2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 26
		gunModel[7].setRotationPoint(6F, -20F, -2.5F);

		gunModel[8].addBox(0F, 0F, 0F, 7, 2, 4, 0F); // Box 27
		gunModel[8].setRotationPoint(8F, -15F, -2F);

		gunModel[9].addShapeBox(0F, 0F, 0F, 2, 2, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F); // Box 28
		gunModel[9].setRotationPoint(6F, -15F, -2F);

		gunModel[10].addShapeBox(0F, 0F, 0F, 2, 2, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, 0F, 0F, 0F); // Box 29
		gunModel[10].setRotationPoint(15F, -15F, -2F);

		gunModel[11].addBox(0F, 0F, 0F, 2, 2, 3, 0F); // Box 30
		gunModel[11].setRotationPoint(10F, -20F, -1.5F);

		gunModel[12].addShapeBox(0F, 0F, 0F, 2, 2, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F); // Box 31
		gunModel[12].setRotationPoint(10F, -18F, -1.5F);

		gunModel[13].addBox(0F, 0F, 0F, 17, 2, 4, 0F); // Box 0
		gunModel[13].setRotationPoint(9F, -22F, -2F);

		gunModel[14].addShapeBox(0F, 0F, 0F, 9, 1, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 2
		gunModel[14].setRotationPoint(17F, -20F, -2F);

		gunModel[15].addShapeBox(0F, 0F, 0F, 2, 1, 5, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F); // Box 11
		gunModel[15].setRotationPoint(-8F, -22F, -2.5F);

		gunModel[16].addShapeBox(0F, 0F, 0F, 2, 1, 5, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F); // Box 12
		gunModel[16].setRotationPoint(-8F, -21F, -2.5F);

		gunModel[17].addShapeBox(0F, 0F, 0F, 9, 9, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 3F, 0F, 0F); // Box 18
		gunModel[17].setRotationPoint(-3F, -16F, -3F);

		gunModel[18].addBox(0F, 0F, 0F, 9, 2, 6, 0F); // Box 19
		gunModel[18].setRotationPoint(-6F, -7F, -3F);

		gunModel[19].addShapeBox(0F, 0F, 0F, 3, 3, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F); // Box 20
		gunModel[19].setRotationPoint(4F, -19F, -3F);

		gunModel[20].addBox(0F, 0F, 0F, 3, 1, 6, 0F); // Box 21
		gunModel[20].setRotationPoint(-5F, -21F, -3F);

		gunModel[21].addShapeBox(0F, 0F, 0F, 7, 2, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 23
		gunModel[21].setRotationPoint(-3F, -18F, -3F);

		gunModel[22].addBox(0F, 0F, 0F, 3, 1, 6, 0F); // Box 24
		gunModel[22].setRotationPoint(4F, -20F, -3F);

		gunModel[23].addShapeBox(0F, 0F, 0F, 3, 2, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F); // Box 25
		gunModel[23].setRotationPoint(-5F, -20F, -3F);

		gunModel[24].addBox(0F, 0F, 0F, 4, 2, 1, 0F); // Box 28
		gunModel[24].setRotationPoint(4F, -22F, 2F);

		gunModel[25].addBox(0F, 0F, 0F, 6, 3, 6, 0F); // Box 29
		gunModel[25].setRotationPoint(-2F, -21F, -3F);

		gunModel[26].addShapeBox(0F, 0F, 0F, 3, 1, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F); // Box 31
		gunModel[26].setRotationPoint(-7F, -3F, -1F);

		gunModel[27].addBox(0F, 0F, 0F, 1, 1, 2, 0F); // Box 32
		gunModel[27].setRotationPoint(-7F, -4F, -1F);

		gunModel[28].addBox(0F, 0F, 0F, 1, 1, 2, 0F); // Box 33
		gunModel[28].setRotationPoint(-5F, -4F, -1F);

		gunModel[29].addShapeBox(0F, 0F, 0F, 1, 3, 5, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F); // Box 35
		gunModel[29].setRotationPoint(4F, -7F, -2.5F);

		gunModel[30].addShapeBox(0F, 0F, 0F, 1, 9, 5, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 3F, 0F, 0F, -3F, 0F, -1F, -3F, 0F, -1F, 3F, 0F, 0F); // Box 36
		gunModel[30].setRotationPoint(7F, -16F, -2.5F);

		gunModel[31].addShapeBox(0F, 0F, 0F, 1, 4, 5, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 2F, 0F, 0F, -2F, 0F, -1F, -2F, 0F, -1F, 2F, 0F, 0F); // Box 37
		gunModel[31].setRotationPoint(9F, -20F, -2.5F);

		gunModel[32].addShapeBox(0F, 0F, 0F, 1, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F); // Box 38
		gunModel[32].setRotationPoint(9F, -22F, -2.5F);


		ammoModel = new ModelRendererTurbo[5];
		ammoModel[0] = new ModelRendererTurbo(this, 1, 18, textureX, textureY); // Box 25
		ammoModel[1] = new ModelRendererTurbo(this, 1, 51, textureX, textureY); // Box 26
		ammoModel[2] = new ModelRendererTurbo(this, 1, 43, textureX, textureY); // Box 27
		ammoModel[3] = new ModelRendererTurbo(this, 1, 35, textureX, textureY); // Box 34
		ammoModel[4] = new ModelRendererTurbo(this, 95, 11, textureX, textureY); // Box 39

		ammoModel[0].addShapeBox(0F, 0F, 0F, 7, 12, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 4F, 0F, 0F, -4F, 0F, 0F, -4F, 0F, 0F, 4F, 0F, 0F); // Box 25
		ammoModel[0].setRotationPoint(0F, -16F, -2F);

		ammoModel[1].addBox(0F, 0F, 0F, 6, 1, 2, 0F); // Box 26
		ammoModel[1].setRotationPoint(1F, -20F, -1F);

		ammoModel[2].addBox(0F, 0F, 0F, 8, 2, 5, 0F); // Box 27
		ammoModel[2].setRotationPoint(-4F, -4F, -2.5F);

		ammoModel[3].addShapeBox(0F, 0F, 0F, 7, 3, 4, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F); // Box 34
		ammoModel[3].setRotationPoint(1F, -19F, -2F);

		ammoModel[4].addShapeBox(0F, 0F, 0F, 1, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F); // Box 39
		ammoModel[4].setRotationPoint(4F, -4F, -2.5F);


		slideModel = new ModelRendererTurbo[15];
		slideModel[0] = new ModelRendererTurbo(this, 32, 9, textureX, textureY); // Box 0
		slideModel[1] = new ModelRendererTurbo(this, 78, 59, textureX, textureY); // Box 9
		slideModel[2] = new ModelRendererTurbo(this, 1, 1, textureX, textureY); // Box 18
		slideModel[3] = new ModelRendererTurbo(this, 25, 1, textureX, textureY); // Box 23
		slideModel[4] = new ModelRendererTurbo(this, 25, 1, textureX, textureY); // Box 24
		slideModel[5] = new ModelRendererTurbo(this, 84, 19, textureX, textureY); // Box 32
		slideModel[6] = new ModelRendererTurbo(this, 63, 59, textureX, textureY); // Box 1
		slideModel[7] = new ModelRendererTurbo(this, 120, 66, textureX, textureY); // Box 4
		slideModel[8] = new ModelRendererTurbo(this, 101, 65, textureX, textureY); // Box 5
		slideModel[9] = new ModelRendererTurbo(this, 118, 39, textureX, textureY); // Box 6
		slideModel[10] = new ModelRendererTurbo(this, 92, 50, textureX, textureY); // Box 9
		slideModel[11] = new ModelRendererTurbo(this, 47, 19, textureX, textureY); // Box 10
		slideModel[12] = new ModelRendererTurbo(this, 32, 19, textureX, textureY); // Box 17
		slideModel[13] = new ModelRendererTurbo(this, 1, 13, textureX, textureY); // Box 27
		slideModel[14] = new ModelRendererTurbo(this, 1, 8, textureX, textureY); // Box 30

		slideModel[0].addBox(0F, 0F, 0F, 25, 3, 6, 0F); // Box 0
		slideModel[0].setRotationPoint(-1F, -25F, -3F);

		slideModel[1].addBox(0F, 0F, 0F, 4, 1, 3, 0F); // Box 9
		slideModel[1].setRotationPoint(26F, -22F, -1.5F);

		slideModel[2].addBox(0F, 0F, 0F, 2, 1, 1, 0F); // Box 18
		slideModel[2].setRotationPoint(28F, -28F, -0.5F);

		slideModel[3].addBox(0F, 0F, 0F, 2, 2, 1, 0F); // Box 23
		slideModel[3].setRotationPoint(0F, -28F, -2F);

		slideModel[4].addBox(0F, 0F, 0F, 2, 2, 1, 0F); // Box 24
		slideModel[4].setRotationPoint(0F, -28F, 1F);

		slideModel[5].addShapeBox(0F, 0F, 0F, 12, 2, 5, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 32
		slideModel[5].setRotationPoint(-1F, -27F, -2.5F);

		slideModel[6].addShapeBox(0F, 0F, 0F, 4, 1, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 1
		slideModel[6].setRotationPoint(26F, -21F, -1.5F);

		slideModel[7].addShapeBox(0F, 0F, 0F, 4, 2, 5, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 4
		slideModel[7].setRotationPoint(26F, -27F, -2.5F);

		slideModel[8].addBox(0F, 0F, 0F, 4, 3, 5, 0F); // Box 5
		slideModel[8].setRotationPoint(26F, -25F, -2.5F);

		slideModel[9].addShapeBox(0F, 0F, 0F, 2, 3, 6, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F); // Box 6
		slideModel[9].setRotationPoint(24F, -25F, -3F);

		slideModel[10].addShapeBox(0F, 0F, 0F, 3, 2, 5, 0F, -2F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, -2F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 9
		slideModel[10].setRotationPoint(-4F, -27F, -2.5F);

		slideModel[11].addShapeBox(0F, 0F, 0F, 5, 3, 2, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 10
		slideModel[11].setRotationPoint(-6F, -25F, -3F);

		slideModel[12].addShapeBox(0F, 0F, 0F, 5, 3, 2, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 17
		slideModel[12].setRotationPoint(-6F, -25F, 1F);

		slideModel[13].addBox(0F, 0F, 0F, 2, 2, 2, 0F); // Box 27
		slideModel[13].setRotationPoint(-2F, -26F, 1.5F);

		slideModel[14].addBox(0F, 0F, 0F, 2, 2, 2, 0F); // Box 30
		slideModel[14].setRotationPoint(-2F, -26F, -3.5F);


		hammerModel = new ModelRendererTurbo[4];
		hammerModel[0] = new ModelRendererTurbo(this, 1, 4, textureX, textureY); // Box 13
		hammerModel[1] = new ModelRendererTurbo(this, 1, 4, textureX, textureY); // Box 14
		hammerModel[2] = new ModelRendererTurbo(this, 12, 4, textureX, textureY); // Box 15
		hammerModel[3] = new ModelRendererTurbo(this, 12, 4, textureX, textureY); // Box 16

		hammerModel[0].addShapeBox(0F, 0F, 0F, 3, 1, 2, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 13
		hammerModel[0].setRotationPoint(-7F, -26F, -1F);

		hammerModel[1].addShapeBox(0F, 0F, 0F, 3, 1, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F); // Box 14
		hammerModel[1].setRotationPoint(-7F, -24F, -1F);

		hammerModel[2].addBox(0F, 0F, 0F, 1, 1, 2, 0F); // Box 15
		hammerModel[2].setRotationPoint(-7F, -25F, -1F);

		hammerModel[3].addBox(0F, 0F, 0F, 1, 1, 2, 0F); // Box 16
		hammerModel[3].setRotationPoint(-5F, -25F, -1F);

//		casingModel = new ModelRendererTurbo[1];
//		casingModel[0] = new ModelRendererTurbo(this, 1, 55, textureX, textureY); // Box 33
//
//		casingModel[0].addBox(0F, 0F, 0F, 4, 2, 2, 0F); // Box 33
//		casingModel[0].setRotationPoint(7F, -24.5F, -1F);
		
		animationType = EnumAnimationType.PISTOL_CLIP;
		gunSlideDistance = 0.8F;

		casingAnimTime = 8;
		slideLockOnEmpty = true;
		RotateSlideDistance = -15F;

		hammerSpinPoint = new Vector3f(-4F / 16F, 23F /16F, 0F / 16F);
		hammerAngle = 90F;

		flipAll();
		translateAll(0F, 0F, 0F);
	}
}