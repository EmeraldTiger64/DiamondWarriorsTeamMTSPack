package com.flansmod.client.model.hltp;

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelMP5 extends ModelGun
{
	int textureX = 512;
	int textureY = 256;

	public ModelMP5()
	{
		gunModel = new ModelRendererTurbo[49];
		gunModel[0] = new ModelRendererTurbo(this, 1, 32, textureX, textureY); // Box 20
		gunModel[1] = new ModelRendererTurbo(this, 1, 48, textureX, textureY); // Box 22
		gunModel[2] = new ModelRendererTurbo(this, 64, 49, textureX, textureY); // Box 0
		gunModel[3] = new ModelRendererTurbo(this, 147, 56, textureX, textureY); // Box 1
		gunModel[4] = new ModelRendererTurbo(this, 63, 41, textureX, textureY); // Box 2
		gunModel[5] = new ModelRendererTurbo(this, 42, 1, textureX, textureY); // Box 3
		gunModel[6] = new ModelRendererTurbo(this, 19, 1, textureX, textureY); // Box 4
		gunModel[7] = new ModelRendererTurbo(this, 1, 7, textureX, textureY); // Box 5
		gunModel[8] = new ModelRendererTurbo(this, 1, 1, textureX, textureY); // Box 6
		gunModel[9] = new ModelRendererTurbo(this, 10, 1, textureX, textureY); // Box 7
		gunModel[10] = new ModelRendererTurbo(this, 1, 57, textureX, textureY); // Box 8
		gunModel[11] = new ModelRendererTurbo(this, 117, 49, textureX, textureY); // Box 9
		gunModel[12] = new ModelRendererTurbo(this, 64, 13, textureX, textureY); // Box 14
		gunModel[13] = new ModelRendererTurbo(this, 64, 1, textureX, textureY); // Box 15
		gunModel[14] = new ModelRendererTurbo(this, 111, 85, textureX, textureY); // Box 16
		gunModel[15] = new ModelRendererTurbo(this, 47, 40, textureX, textureY); // Box 19
		gunModel[16] = new ModelRendererTurbo(this, 72, 61, textureX, textureY); // Box 20
		gunModel[17] = new ModelRendererTurbo(this, 38, 18, textureX, textureY); // Box 21
		gunModel[18] = new ModelRendererTurbo(this, 64, 33, textureX, textureY); // Box 22
		gunModel[19] = new ModelRendererTurbo(this, 64, 25, textureX, textureY); // Box 23
		gunModel[20] = new ModelRendererTurbo(this, 47, 40, textureX, textureY); // Box 32
		gunModel[21] = new ModelRendererTurbo(this, 47, 40, textureX, textureY); // Box 33
		gunModel[22] = new ModelRendererTurbo(this, 32, 40, textureX, textureY); // Box 34
		gunModel[23] = new ModelRendererTurbo(this, 32, 40, textureX, textureY); // Box 35
		gunModel[24] = new ModelRendererTurbo(this, 32, 40, textureX, textureY); // Box 36
		gunModel[25] = new ModelRendererTurbo(this, 152, 7, textureX, textureY); // Box 37
		gunModel[26] = new ModelRendererTurbo(this, 152, 1, textureX, textureY); // Box 38
		gunModel[27] = new ModelRendererTurbo(this, 1, 25, textureX, textureY); // Box 39
		gunModel[28] = new ModelRendererTurbo(this, 12, 10, textureX, textureY); // Box 40
		gunModel[29] = new ModelRendererTurbo(this, 132, 71, textureX, textureY); // Box 41
		gunModel[30] = new ModelRendererTurbo(this, 80, 84, textureX, textureY); // Box 42
		gunModel[31] = new ModelRendererTurbo(this, 111, 71, textureX, textureY); // Box 43
		gunModel[32] = new ModelRendererTurbo(this, 80, 71, textureX, textureY); // Box 44
		gunModel[33] = new ModelRendererTurbo(this, 101, 73, textureX, textureY); // Box 45
		gunModel[34] = new ModelRendererTurbo(this, 129, 61, textureX, textureY); // Box 46
		gunModel[35] = new ModelRendererTurbo(this, 29, 58, textureX, textureY); // Box 55
		gunModel[36] = new ModelRendererTurbo(this, 44, 58, textureX, textureY); // Box 56
		gunModel[37] = new ModelRendererTurbo(this, 29, 58, textureX, textureY); // Box 57
		gunModel[38] = new ModelRendererTurbo(this, 1, 17, textureX, textureY); // Box 58
		gunModel[39] = new ModelRendererTurbo(this, 42, 9, textureX, textureY); // Box 59
		gunModel[40] = new ModelRendererTurbo(this, 8, 17, textureX, textureY); // Box 60
		gunModel[41] = new ModelRendererTurbo(this, 8, 17, textureX, textureY); // Box 61
		gunModel[42] = new ModelRendererTurbo(this, 12, 11, textureX, textureY); // Box 62
		gunModel[43] = new ModelRendererTurbo(this, 12, 19, textureX, textureY); // Box 63
		gunModel[44] = new ModelRendererTurbo(this, 12, 19, textureX, textureY); // Box 64
		gunModel[45] = new ModelRendererTurbo(this, 25, 18, textureX, textureY); // Box 65
		gunModel[46] = new ModelRendererTurbo(this, 27, 10, textureX, textureY); // Box 66
		gunModel[47] = new ModelRendererTurbo(this, 39, 8, textureX, textureY); // Box 67
		gunModel[48] = new ModelRendererTurbo(this, 22, 10, textureX, textureY); // Box 68

		gunModel[0].addShapeBox(0F, 0F, 0F, 10, 10, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 4F, 0F, 0F, -4F, 0F, 0F, -4F, 0F, 0F, 4F, 0F, 0F); // Box 20
		gunModel[0].setRotationPoint(-3F, -12F, -2.5F);

		gunModel[1].addShapeBox(0F, 0F, 0F, 10, 3, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F); // Box 22
		gunModel[1].setRotationPoint(-7F, -2F, -2.5F);

		gunModel[2].addBox(0F, 0F, 0F, 20, 5, 6, 0F); // Box 0
		gunModel[2].setRotationPoint(-3F, -17F, -3F);

		gunModel[3].addShapeBox(0F, 0F, 0F, 4, 5, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -4F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -4F, 0F); // Box 1
		gunModel[3].setRotationPoint(-7F, -17F, -3F);

		gunModel[4].addBox(0F, 0F, 0F, 32, 1, 6, 0F); // Box 2
		gunModel[4].setRotationPoint(-7F, -18F, -3F);

		gunModel[5].addShapeBox(0F, 0F, 0F, 2, 1, 4, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, 0F, 0F); // Box 3
		gunModel[5].setRotationPoint(5F, -8F, -2F);

		gunModel[6].addShapeBox(0F, 0F, 0F, 7, 1, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F); // Box 4
		gunModel[6].setRotationPoint(7F, -7F, -2F);

		gunModel[7].addShapeBox(0F, 0F, 0F, 1, 5, 4, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 5
		gunModel[7].setRotationPoint(13F, -12F, -2F);

		gunModel[8].addBox(0F, 0F, 0F, 1, 2, 3, 0F); // Box 6
		gunModel[8].setRotationPoint(9F, -12F, -1.5F);

		gunModel[9].addShapeBox(0F, 0F, 0F, 1, 2, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F); // Box 7
		gunModel[9].setRotationPoint(9F, -10F, -1.5F);

		gunModel[10].addBox(0F, 0F, 0F, 1, 4, 4, 0F); // Box 8
		gunModel[10].setRotationPoint(16F, -12F, -2F);

		gunModel[11].addShapeBox(0F, 0F, 0F, 8, 5, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 0F, 0F); // Box 9
		gunModel[11].setRotationPoint(17F, -17F, -3F);

		gunModel[12].addShapeBox(0F, 0F, 0F, 32, 2, 9, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F); // Box 14
		gunModel[12].setRotationPoint(-7F, -20F, -4.5F);

		gunModel[13].addShapeBox(0F, 0F, 0F, 32, 2, 9, 0F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 15
		gunModel[13].setRotationPoint(-7F, -24F, -4.5F);

		gunModel[14].addBox(0F, 0F, 0F, 11, 2, 9, 0F); // Box 16
		gunModel[14].setRotationPoint(14F, -22F, -4.5F);

		gunModel[15].addBox(0F, 0F, 0F, 2, 2, 5, 0F); // Box 19
		gunModel[15].setRotationPoint(45F, -21.5F, -2.5F);

		gunModel[16].addBox(0F, 0F, 0F, 21, 2, 7, 0F); // Box 20
		gunModel[16].setRotationPoint(-7F, -22F, -3.5F);

		gunModel[17].addBox(0F, 0F, 0F, 7, 3, 3, 0F); // Box 21
		gunModel[17].setRotationPoint(47F, -22F, -1.5F);

		gunModel[18].addBox(0F, 0F, 0F, 32, 2, 5, 0F); // Box 22
		gunModel[18].setRotationPoint(-7F, -26F, -2.5F);

		gunModel[19].addShapeBox(0F, 0F, 0F, 32, 2, 5, 0F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 23
		gunModel[19].setRotationPoint(-7F, -28F, -2.5F);

		gunModel[20].addShapeBox(0F, 0F, 0F, 2, 2, 5, 0F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 32
		gunModel[20].setRotationPoint(45F, -23.5F, -2.5F);

		gunModel[21].addShapeBox(0F, 0F, 0F, 2, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F); // Box 33
		gunModel[21].setRotationPoint(45F, -19.5F, -2.5F);

		gunModel[22].addShapeBox(0F, 0F, 0F, 2, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F); // Box 34
		gunModel[22].setRotationPoint(45F, -24.5F, -2.5F);

		gunModel[23].addBox(0F, 0F, 0F, 2, 2, 5, 0F); // Box 35
		gunModel[23].setRotationPoint(45F, -26.5F, -2.5F);

		gunModel[24].addShapeBox(0F, 0F, 0F, 2, 2, 5, 0F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 36
		gunModel[24].setRotationPoint(45F, -28.5F, -2.5F);

		gunModel[25].addBox(0F, 0F, 0F, 20, 2, 4, 0F); // Box 37
		gunModel[25].setRotationPoint(25F, -26F, -2F);

		gunModel[26].addShapeBox(0F, 0F, 0F, 20, 1, 4, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 38
		gunModel[26].setRotationPoint(25F, -27F, -2F);

		gunModel[27].addBox(0F, 0F, 0F, 1, 3, 3, 0F); // Box 39
		gunModel[27].setRotationPoint(47F, -27F, -1.5F);

		gunModel[28].addShapeBox(0F, 0F, 0F, 2, 1, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 40
		gunModel[28].setRotationPoint(45F, -29F, -2.5F);

		gunModel[29].addBox(0F, 0F, 0F, 5, 2, 7, 0F); // Box 41
		gunModel[29].setRotationPoint(-12F, -18F, -3.5F);

		gunModel[30].addShapeBox(0F, 0F, 0F, 5, 2, 10, 0F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 42
		gunModel[30].setRotationPoint(-12F, -24F, -5F);

		gunModel[31].addShapeBox(0F, 0F, 0F, 5, 2, 10, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F); // Box 43
		gunModel[31].setRotationPoint(-12F, -20F, -5F);

		gunModel[32].addBox(0F, 0F, 0F, 5, 2, 10, 0F); // Box 44
		gunModel[32].setRotationPoint(-12F, -22F, -5F);

		gunModel[33].addShapeBox(0F, 0F, 0F, 3, 2, 5, 0F, -2F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, -2F, -0.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 45
		gunModel[33].setRotationPoint(-10F, -28F, -2.5F);

		gunModel[34].addShapeBox(0F, 0F, 0F, 5, 2, 7, 0F, -2F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, -2F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 46
		gunModel[34].setRotationPoint(-12F, -26F, -3.5F);

		gunModel[35].addShapeBox(0F, 0F, 0F, 2, 2, 5, 0F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 55
		gunModel[35].setRotationPoint(-14F, -23.5F, -2.5F);

		gunModel[36].addBox(0F, 0F, 0F, 2, 2, 5, 0F); // Box 56
		gunModel[36].setRotationPoint(-14F, -21.5F, -2.5F);

		gunModel[37].addShapeBox(0F, 0F, 0F, 2, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F); // Box 57
		gunModel[37].setRotationPoint(-14F, -19.5F, -2.5F);

		gunModel[38].addBox(0F, 0F, 0F, 1, 3, 4, 0F); // Box 58
		gunModel[38].setRotationPoint(-6F, -29F, -2F);

		gunModel[39].addShapeBox(0F, 0F, 0F, 4, 3, 4, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 59
		gunModel[39].setRotationPoint(-5F, -29F, -2F);

		gunModel[40].addBox(0F, 0F, 0F, 1, 2, 1, 0F); // Box 60
		gunModel[40].setRotationPoint(-6F, -31F, -2F);

		gunModel[41].addBox(0F, 0F, 0F, 1, 2, 1, 0F); // Box 61
		gunModel[41].setRotationPoint(-6F, -31F, 1F);

		gunModel[42].addBox(0F, 0F, 0F, 1, 2, 1, 0F); // Box 62
		gunModel[42].setRotationPoint(45.5F, -31F, -0.5F);

		gunModel[43].addShapeBox(0F, 0F, 0F, 2, 1, 4, 0F, 0F, 0.5F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, -0.5F, 0F); // Box 63
		gunModel[43].setRotationPoint(-3F, -29F, -2F);

		gunModel[44].addShapeBox(0F, 0F, 0F, 2, 1, 4, 0F, 0F, 0F, -1F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0.5F, 0F, 0F, 0.5F, 0F, 0F, 0F, -1F); // Box 64
		gunModel[44].setRotationPoint(-5F, -30F, -2F);

		gunModel[45].addBox(0F, 0F, 0F, 2, 2, 4, 0F); // Box 65
		gunModel[45].setRotationPoint(35F, -26.5F, 1.5F);

		gunModel[46].addShapeBox(0F, 0F, 0F, 2, 1, 5, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 66
		gunModel[46].setRotationPoint(45F, -33F, -2.5F);

		gunModel[47].addBox(0F, 0F, 0F, 2, 3, 1, 0F); // Box 67
		gunModel[47].setRotationPoint(45F, -32F, -2.5F);

		gunModel[48].addBox(0F, 0F, 0F, 2, 3, 1, 0F); // Box 68
		gunModel[48].setRotationPoint(45F, -32F, 1.5F);


		defaultStockModel = new ModelRendererTurbo[7];
		defaultStockModel[0] = new ModelRendererTurbo(this, 21, 84, textureX, textureY); // Box 47
		defaultStockModel[1] = new ModelRendererTurbo(this, 21, 84, textureX, textureY); // Box 48
		defaultStockModel[2] = new ModelRendererTurbo(this, 51, 88, textureX, textureY); // Box 49
		defaultStockModel[3] = new ModelRendererTurbo(this, 20, 88, textureX, textureY); // Box 50
		defaultStockModel[4] = new ModelRendererTurbo(this, 20, 88, textureX, textureY); // Box 51
		defaultStockModel[5] = new ModelRendererTurbo(this, 1, 81, textureX, textureY); // Box 52
		defaultStockModel[6] = new ModelRendererTurbo(this, 32, 50, textureX, textureY); // Box 53

		defaultStockModel[0].addBox(0F, 0F, 0F, 26, 2, 1, 0F); // Box 47
		defaultStockModel[0].setRotationPoint(-27F, -22F, -4.5F);

		defaultStockModel[1].addBox(0F, 0F, 0F, 26, 2, 1, 0F); // Box 48
		defaultStockModel[1].setRotationPoint(-27F, -22F, 3.5F);

		defaultStockModel[2].addBox(0F, 0F, 0F, 5, 2, 10, 0F); // Box 49
		defaultStockModel[2].setRotationPoint(-32F, -22F, -5F);

		defaultStockModel[3].addShapeBox(0F, 0F, 0F, 5, 2, 10, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F); // Box 50
		defaultStockModel[3].setRotationPoint(-32F, -20F, -5F);

		defaultStockModel[4].addShapeBox(0F, 0F, 0F, 5, 2, 10, 0F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 51
		defaultStockModel[4].setRotationPoint(-32F, -24F, -5F);

		defaultStockModel[5].addShapeBox(0F, 0F, 0F, 5, 15, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F); // Box 52
		defaultStockModel[5].setRotationPoint(-32F, -18F, -2F);

		defaultStockModel[6].addShapeBox(0F, 0F, 0F, 5, 2, 5, 0F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, -0.5F, -1.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 53
		defaultStockModel[6].setRotationPoint(-32F, -26F, -2.5F);

		defaultGripModel = new ModelRendererTurbo[3];
		defaultGripModel[0] = new ModelRendererTurbo(this, 152, 14, textureX, textureY); // Box 24
		defaultGripModel[1] = new ModelRendererTurbo(this, 152, 40, textureX, textureY); // Box 25
		defaultGripModel[2] = new ModelRendererTurbo(this, 152, 27, textureX, textureY); // Box 26

		defaultGripModel[0].addShapeBox(0F, 0F, 0F, 20, 3, 9, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 24
		defaultGripModel[0].setRotationPoint(25F, -25F, -4.5F);

		defaultGripModel[1].addShapeBox(0F, 0F, 0F, 20, 3, 9, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F); // Box 25
		defaultGripModel[1].setRotationPoint(25F, -19F, -4.5F);

		defaultGripModel[2].addBox(0F, 0F, 0F, 20, 3, 9, 0F); // Box 26
		defaultGripModel[2].setRotationPoint(25F, -22F, -4.5F);

		ammoModel = new ModelRendererTurbo[4];
		ammoModel[0] = new ModelRendererTurbo(this, 12, 62, textureX, textureY); // Box 26
		ammoModel[1] = new ModelRendererTurbo(this, 47, 66, textureX, textureY); // Box 11
		ammoModel[2] = new ModelRendererTurbo(this, 24, 66, textureX, textureY); // Box 12
		ammoModel[3] = new ModelRendererTurbo(this, 1, 66, textureX, textureY); // Box 13

		ammoModel[0].addBox(0F, 0F, 0F, 6, 1, 2, 0F); // Box 26
		ammoModel[0].setRotationPoint(17F, -20F, -1F);

		ammoModel[1].addShapeBox(0F, 0F, 0F, 7, 13, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 0F, 0F); // Box 11
		ammoModel[1].setRotationPoint(17F, -19F, -2F);

		ammoModel[2].addShapeBox(0F, 0F, 0F, 7, 12, 4, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, -2F, 0F, 0F, 2F, -3F, 0F, 2F, -3F, 0F, -2F, 0F, 0F); // Box 12
		ammoModel[2].setRotationPoint(17F, -9F, -2F);

		ammoModel[3].addShapeBox(0F, 0F, 0F, 7, 10, 4, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, -4F, 0F, 0F, 4F, -3F, 0F, 4F, -3F, 0F, -4F, 0F, 0F); // Box 13
		ammoModel[3].setRotationPoint(19F, 0F, -2F);

		hasFlash = true;
		//muzzleFlashPoint = new Vector3f(54F / 16F, -31F / 16F, -10.5F / 16F);

		gripAttachPoint = new Vector3f(25 /16F, 20.5F /16F, 0F /16F);
		casingAttachPoint = new Vector3f(12F /16F, 25F /16F, 2F /16F);
		//muzzleFlashPoint = new Vector3f(54F / 16F, 20.5F / 16F, 0F);

		animationType = EnumAnimationType.BOTTOM_CLIP;

		casingAnimTime = 7;
		RotateSlideDistance = -5F;

		flipAll();
		translateAll(0F, 0F, 0F);
	}
}