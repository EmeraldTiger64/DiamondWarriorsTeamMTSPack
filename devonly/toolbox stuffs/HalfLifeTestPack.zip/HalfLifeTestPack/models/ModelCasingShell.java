package com.flansmod.client.model.hltp;

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelCasing;
import com.flansmod.client.tmt.ModelRendererTurbo;

import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelCasingShell extends ModelCasing
{
	int textureX = 512;
	int textureY = 256;

	public ModelCasingShell()
	{
		casingModel = new ModelRendererTurbo[2];
		casingModel[0] = new ModelRendererTurbo(this, 30, 1, textureX, textureY); // Box 17
		casingModel[1] = new ModelRendererTurbo(this, 30, 1, textureX, textureY); // Box 18

		casingModel[0].addShapeBox(0F, -1F, 0F, 10, 2, 4, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 17
		casingModel[0].setRotationPoint(0F, 0F, 0F);

		casingModel[1].addShapeBox(0F, 1F, 0F, 10, 2, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 18
		casingModel[1].setRotationPoint(0F, 0F, 0F);

		flipAll();
	}
}