package com.flansmod.client.model.hltp;

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelAttachment;
import com.flansmod.client.tmt.ModelRendererTurbo;

import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelSmallLauncher extends ModelAttachment
{
	int textureX = 512;
	int textureY = 256;

	public ModelSmallLauncher()
	{
		attachmentModel = new ModelRendererTurbo[14];
		attachmentModel[0] = new ModelRendererTurbo(this, 258, 46, textureX, textureY); // Box 67
		attachmentModel[1] = new ModelRendererTurbo(this, 211, 55, textureX, textureY); // Box 68
		attachmentModel[2] = new ModelRendererTurbo(this, 211, 66, textureX, textureY); // Box 69
		attachmentModel[3] = new ModelRendererTurbo(this, 236, 68, textureX, textureY); // Box 70
		attachmentModel[4] = new ModelRendererTurbo(this, 211, 44, textureX, textureY); // Box 71
		attachmentModel[5] = new ModelRendererTurbo(this, 211, 29, textureX, textureY); // Box 72
		attachmentModel[6] = new ModelRendererTurbo(this, 211, 15, textureX, textureY); // Box 73
		attachmentModel[7] = new ModelRendererTurbo(this, 211, 1, textureX, textureY); // Box 74
		attachmentModel[8] = new ModelRendererTurbo(this, 269, 55, textureX, textureY); // Box 75
		attachmentModel[9] = new ModelRendererTurbo(this, 256, 55, textureX, textureY); // Box 76
		attachmentModel[10] = new ModelRendererTurbo(this, 10, 1, textureX, textureY); // Box 77
		attachmentModel[11] = new ModelRendererTurbo(this, 1, 1, textureX, textureY); // Box 78
		attachmentModel[12] = new ModelRendererTurbo(this, 261, 66, textureX, textureY); // Box 79
		attachmentModel[13] = new ModelRendererTurbo(this, 261, 73, textureX, textureY); // Box 80

		attachmentModel[0].addBox(5F, -3.5F, -2.5F, 15, 3, 5, 0F); // Box 67
		attachmentModel[0].setRotationPoint(0F, 0F, 0F);

		attachmentModel[1].addBox(5F, -0.5F, -3.5F, 15, 3, 7, 0F); // Box 68
		attachmentModel[1].setRotationPoint(0F, 0F, 0F);

		attachmentModel[2].addBox(0F, -3.5F, -3.5F, 5, 7, 7, 0F); // Box 69
		attachmentModel[2].setRotationPoint(0F, 0F, 0F);

		attachmentModel[3].addBox(0F, 3.5F, -2.5F, 7, 7, 5, 0F); // Box 70
		attachmentModel[3].setRotationPoint(0F, 0F, 0F);

		attachmentModel[4].addBox(5F, 2.5F, -3.5F, 16, 3, 7, 0F); // Box 71
		attachmentModel[4].setRotationPoint(0F, 0F, 0F);

		attachmentModel[5].addBox(7F, 6.5F, -5F, 25, 4, 10, 0F); // Box 72
		attachmentModel[5].setRotationPoint(0F, 0F, 0F);

		attachmentModel[6].addShapeBox(7F, 3.5F, -5F, 25, 3, 10, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 73
		attachmentModel[6].setRotationPoint(0F, 0F, 0F);

		attachmentModel[7].addShapeBox(7F, 10.5F, -5F, 25, 3, 10, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F); // Box 74
		attachmentModel[7].setRotationPoint(0F, 0F, 0F);

		attachmentModel[8].addBox(0F, 10.5F, -2.5F, 1, 4, 5, 0F); // Box 75
		attachmentModel[8].setRotationPoint(0F, 0F, 0F);

		attachmentModel[9].addBox(6F, 10.5F, -2.5F, 1, 4, 5, 0F); // Box 76
		attachmentModel[9].setRotationPoint(0F, 0F, 0F);

		attachmentModel[10].addShapeBox(2F, 12F, -1.5F, 1, 2, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F); // Box 77
		attachmentModel[10].setRotationPoint(0F, 0F, 0F);

		attachmentModel[11].addBox(2F, 10F, -1.5F, 1, 2, 3, 0F); // Box 78
		attachmentModel[11].setRotationPoint(0F, 0F, 0F);

		attachmentModel[12].addShapeBox(0F, 14.5F, -2.5F, 7, 1, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F); // Box 79
		attachmentModel[12].setRotationPoint(0F, 0F, 0F);

		attachmentModel[13].addShapeBox(27F, 13.5F, -2F, 5, 3, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F); // Box 80
		attachmentModel[13].setRotationPoint(0F, 0F, 0F);

		ammoModel = new ModelRendererTurbo[6];
		ammoModel[0] = new ModelRendererTurbo(this, 282, 15, textureX, textureY); // Box 81
		ammoModel[1] = new ModelRendererTurbo(this, 282, 2, textureX, textureY); // Box 82
		ammoModel[2] = new ModelRendererTurbo(this, 282, 2, textureX, textureY); // Box 83
		ammoModel[3] = new ModelRendererTurbo(this, 282, 28, textureX, textureY); // Box 84
		ammoModel[4] = new ModelRendererTurbo(this, 282, 28, textureX, textureY); // Box 85
		ammoModel[5] = new ModelRendererTurbo(this, 282, 28, textureX, textureY); // Box 87

		ammoModel[0].addBox(13F, 7F, -4.5F, 12, 3, 9, 0F); // Box 81
		ammoModel[0].setRotationPoint(0F, 0F, 0F);

		ammoModel[1].addShapeBox(13F, 4F, -4.5F, 12, 3, 9, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 82
		ammoModel[1].setRotationPoint(0F, 0F, 0F);

		ammoModel[2].addShapeBox(13F, 10F, -4.5F, 12, 3, 9, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, -3F); // Box 83
		ammoModel[2].setRotationPoint(0F, 0F, 0F);

		ammoModel[3].addShapeBox(25F, 4F, -4.5F, 5, 3, 9, 0F, 0F, 0F, -3F, 0F, -3F, -4F, 0F, -3F, -4F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 1F, -3F, 0F, 1F, -3F, 0F, 0F, 0F); // Box 84
		ammoModel[3].setRotationPoint(0F, 0F, 0F);

		ammoModel[4].addShapeBox(25F, 7F, -4.5F, 5, 3, 9, 0F, 0F, 0F, 0F, 0F, -1F, -3F, 0F, -1F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, -3F, 0F, -1F, -3F, 0F, 0F, 0F); // Box 85
		ammoModel[4].setRotationPoint(0F, 0F, 0F);

		ammoModel[5].addShapeBox(25F, 10F, -4.5F, 5, 3, 9, 0F, 0F, 0F, 0F, 0F, 1F, -3F, 0F, 1F, -3F, 0F, 0F, 0F, 0F, 0F, -3F, 0F, -3F, -4F, 0F, -3F, -4F, 0F, 0F, -3F); // Box 87
		ammoModel[5].setRotationPoint(0F, 0F, 0F);

		secondaryAnimType = EnumAnimationType.END_LOADED;
		endLoadedAmmoDistance = 2.2F;

		renderOffset = 0F;

		flipAll();
	}
}