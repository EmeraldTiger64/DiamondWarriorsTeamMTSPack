package com.flansmod.client.model.hltp;

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelAR2 extends ModelGun
{
	int textureX = 512;
	int textureY = 256;

	public ModelAR2()
	{
		gunModel = new ModelRendererTurbo[72];
		gunModel[0] = new ModelRendererTurbo(this, 1, 20, textureX, textureY); // Box 0
		gunModel[1] = new ModelRendererTurbo(this, 1, 12, textureX, textureY); // Box 1
		gunModel[2] = new ModelRendererTurbo(this, 45, 23, textureX, textureY); // Box 2
		gunModel[3] = new ModelRendererTurbo(this, 28, 24, textureX, textureY); // Box 3
		gunModel[4] = new ModelRendererTurbo(this, 10, 7, textureX, textureY); // Box 4
		gunModel[5] = new ModelRendererTurbo(this, 1, 3, textureX, textureY); // Box 5
		gunModel[6] = new ModelRendererTurbo(this, 28, 13, textureX, textureY); // Box 6
		gunModel[7] = new ModelRendererTurbo(this, 7, 1, textureX, textureY); // Box 7
		gunModel[8] = new ModelRendererTurbo(this, 7, 1, textureX, textureY); // Box 8
		gunModel[9] = new ModelRendererTurbo(this, 80, 1, textureX, textureY); // Box 9
		gunModel[10] = new ModelRendererTurbo(this, 80, 11, textureX, textureY); // Box 11
		gunModel[11] = new ModelRendererTurbo(this, 80, 57, textureX, textureY); // Box 12
		gunModel[12] = new ModelRendererTurbo(this, 133, 67, textureX, textureY); // Box 13
		gunModel[13] = new ModelRendererTurbo(this, 123, 78, textureX, textureY); // Box 14
		gunModel[14] = new ModelRendererTurbo(this, 80, 76, textureX, textureY); // Box 15
		gunModel[15] = new ModelRendererTurbo(this, 172, 42, textureX, textureY); // Box 16
		gunModel[16] = new ModelRendererTurbo(this, 166, 77, textureX, textureY); // Box 17
		gunModel[17] = new ModelRendererTurbo(this, 172, 38, textureX, textureY); // Box 18
		gunModel[18] = new ModelRendererTurbo(this, 157, 47, textureX, textureY); // Box 19
		gunModel[19] = new ModelRendererTurbo(this, 130, 47, textureX, textureY); // Box 20
		gunModel[20] = new ModelRendererTurbo(this, 109, 46, textureX, textureY); // Box 21
		gunModel[21] = new ModelRendererTurbo(this, 80, 46, textureX, textureY); // Box 22
		gunModel[22] = new ModelRendererTurbo(this, 150, 29, textureX, textureY); // Box 23
		gunModel[23] = new ModelRendererTurbo(this, 149, 22, textureX, textureY); // Box 24
		gunModel[24] = new ModelRendererTurbo(this, 137, 27, textureX, textureY); // Box 25
		gunModel[25] = new ModelRendererTurbo(this, 80, 19, textureX, textureY); // Box 26
		gunModel[26] = new ModelRendererTurbo(this, 80, 34, textureX, textureY); // Box 27
		gunModel[27] = new ModelRendererTurbo(this, 80, 27, textureX, textureY); // Box 28
		gunModel[28] = new ModelRendererTurbo(this, 159, 11, textureX, textureY); // Box 36
		gunModel[29] = new ModelRendererTurbo(this, 159, 1, textureX, textureY); // Box 39
		gunModel[30] = new ModelRendererTurbo(this, 159, 1, textureX, textureY); // Box 40
		gunModel[31] = new ModelRendererTurbo(this, 210, 1, textureX, textureY); // Box 41
		gunModel[32] = new ModelRendererTurbo(this, 210, 12, textureX, textureY); // Box 44
		gunModel[33] = new ModelRendererTurbo(this, 233, 1, textureX, textureY); // Box 47
		gunModel[34] = new ModelRendererTurbo(this, 233, 11, textureX, textureY); // Box 48
		gunModel[35] = new ModelRendererTurbo(this, 233, 1, textureX, textureY); // Box 49
		gunModel[36] = new ModelRendererTurbo(this, 123, 101, textureX, textureY); // Box 37
		gunModel[37] = new ModelRendererTurbo(this, 123, 94, textureX, textureY); // Box 38
		gunModel[38] = new ModelRendererTurbo(this, 80, 67, textureX, textureY); // Box 40
		gunModel[39] = new ModelRendererTurbo(this, 123, 86, textureX, textureY); // Box 41
		gunModel[40] = new ModelRendererTurbo(this, 158, 58, textureX, textureY); // Box 42
		gunModel[41] = new ModelRendererTurbo(this, 166, 87, textureX, textureY); // Box 43
		gunModel[42] = new ModelRendererTurbo(this, 171, 57, textureX, textureY); // Box 44
		gunModel[43] = new ModelRendererTurbo(this, 172, 63, textureX, textureY); // Box 45
		gunModel[44] = new ModelRendererTurbo(this, 134, 63, textureX, textureY); // Box 56
		gunModel[45] = new ModelRendererTurbo(this, 151, 35, textureX, textureY); // Box 57
		gunModel[46] = new ModelRendererTurbo(this, 130, 37, textureX, textureY); // Box 58
		gunModel[47] = new ModelRendererTurbo(this, 111, 37, textureX, textureY); // Box 59
		gunModel[48] = new ModelRendererTurbo(this, 153, 2, textureX, textureY); // Box 60
		gunModel[49] = new ModelRendererTurbo(this, 149, 12, textureX, textureY); // Box 61
		gunModel[50] = new ModelRendererTurbo(this, 153, 2, textureX, textureY); // Box 62
		gunModel[51] = new ModelRendererTurbo(this, 107, 62, textureX, textureY); // Box 63
		gunModel[52] = new ModelRendererTurbo(this, 80, 62, textureX, textureY); // Box 64
		gunModel[53] = new ModelRendererTurbo(this, 1, 122, textureX, textureY); // Box 65
		gunModel[54] = new ModelRendererTurbo(this, 1, 135, textureX, textureY); // Box 66
		gunModel[55] = new ModelRendererTurbo(this, 36, 135, textureX, textureY); // Box 67
		gunModel[56] = new ModelRendererTurbo(this, 1, 113, textureX, textureY); // Box 68
		gunModel[57] = new ModelRendererTurbo(this, 192, 22, textureX, textureY); // Box 69
		gunModel[58] = new ModelRendererTurbo(this, 192, 32, textureX, textureY); // Box 70
		gunModel[59] = new ModelRendererTurbo(this, 192, 42, textureX, textureY); // Box 72
		gunModel[60] = new ModelRendererTurbo(this, 207, 42, textureX, textureY); // Box 73
		gunModel[61] = new ModelRendererTurbo(this, 97, 86, textureX, textureY); // Box 74
		gunModel[62] = new ModelRendererTurbo(this, 137, 58, textureX, textureY); // Box 75
		gunModel[63] = new ModelRendererTurbo(this, 97, 101, textureX, textureY); // Box 76
		gunModel[64] = new ModelRendererTurbo(this, 114, 91, textureX, textureY); // Box 77
		gunModel[65] = new ModelRendererTurbo(this, 80, 101, textureX, textureY); // Box 78
		gunModel[66] = new ModelRendererTurbo(this, 80, 86, textureX, textureY); // Box 79
		gunModel[67] = new ModelRendererTurbo(this, 41, 11, textureX, textureY); // Box 80
		gunModel[68] = new ModelRendererTurbo(this, 41, 11, textureX, textureY); // Box 81
		gunModel[69] = new ModelRendererTurbo(this, 23, 13, textureX, textureY); // Box 82
		gunModel[70] = new ModelRendererTurbo(this, 23, 20, textureX, textureY); // Box 83
		gunModel[71] = new ModelRendererTurbo(this, 23, 20, textureX, textureY); // Box 84

		gunModel[0].addShapeBox(0F, 0F, 0F, 8, 8, 5, 0F, -4F, 0F, 0F, 4F, 0F, 0F, 4F, 0F, 0F, -4F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 0
		gunModel[0].setRotationPoint(-11F, -2F, -2.5F);

		gunModel[1].addShapeBox(0F, 0F, 0F, 8, 2, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F); // Box 1
		gunModel[1].setRotationPoint(-11F, 6F, -2.5F);

		gunModel[2].addBox(0F, 0F, 0F, 7, 5, 5, 0F); // Box 2
		gunModel[2].setRotationPoint(-6F, -7F, -2.5F);

		gunModel[3].addShapeBox(0F, 0F, 0F, 3, 4, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F); // Box 3
		gunModel[3].setRotationPoint(-9F, -7F, -2.5F);

		gunModel[4].addShapeBox(0F, 0F, 0F, 8, 1, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F); // Box 4
		gunModel[4].setRotationPoint(1F, -2F, -1.5F);

		gunModel[5].addBox(0F, 0F, 0F, 1, 5, 3, 0F); // Box 5
		gunModel[5].setRotationPoint(8F, -7F, -1.5F);

		gunModel[6].addBox(0F, 0F, 0F, 1, 1, 5, 0F); // Box 6
		gunModel[6].setRotationPoint(-7F, -3F, -2.5F);

		gunModel[7].addBox(0F, 0F, 0F, 1, 2, 2, 0F); // Box 7
		gunModel[7].setRotationPoint(2F, -7F, -1F);

		gunModel[8].addShapeBox(0F, 0F, 0F, 1, 2, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F); // Box 8
		gunModel[8].setRotationPoint(2F, -5F, -1F);

		gunModel[9].addBox(0F, 0F, 0F, 33, 3, 6, 0F); // Box 9
		gunModel[9].setRotationPoint(-8F, -10F, -3F);

		gunModel[10].addShapeBox(0F, 0F, 0F, 31, 1, 6, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 11
		gunModel[10].setRotationPoint(-6F, -11F, -3F);

		gunModel[11].addBox(0F, 0F, 0F, 25, 1, 3, 0F); // Box 12
		gunModel[11].setRotationPoint(1F, -12F, -1F);

		gunModel[12].addBox(0F, 0F, 0F, 17, 4, 4, 0F); // Box 13
		gunModel[12].setRotationPoint(9F, -7F, -2F);

		gunModel[13].addShapeBox(0F, 0F, 0F, 15, 1, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 14
		gunModel[13].setRotationPoint(10F, -3F, -3F);

		gunModel[14].addBox(0F, 0F, 0F, 15, 3, 6, 0F); // Box 15
		gunModel[14].setRotationPoint(10F, -6F, -3F);

		gunModel[15].addBox(0F, 0F, 0F, 5, 2, 1, 0F); // Box 16
		gunModel[15].setRotationPoint(7F, -12F, 1.5F);

		gunModel[16].addBox(0F, 0F, 0F, 1, 4, 4, 0F); // Box 17
		gunModel[16].setRotationPoint(25F, -11F, -2F);

		gunModel[17].addBox(0F, 0F, 0F, 3, 2, 1, 0F); // Box 18
		gunModel[17].setRotationPoint(21F, -12F, 1.5F);

		gunModel[18].addShapeBox(0F, 0F, 0F, 3, 3, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F); // Box 19
		gunModel[18].setRotationPoint(-11F, -10F, -3F);

		gunModel[19].addShapeBox(0F, 0F, 0F, 7, 3, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 2F, 0F, 0F, 2F, 0F, 0F, -2F, 0F, 0F); // Box 20
		gunModel[19].setRotationPoint(-13F, -13F, -3F);

		gunModel[20].addShapeBox(0F, 0F, 0F, 4, 4, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 3F, 0F, 0F, 3F, 0F, 0F, 0F, 0F, 0F); // Box 21
		gunModel[20].setRotationPoint(-13F, -17F, -3F);

		gunModel[21].addBox(0F, 0F, 0F, 8, 4, 6, 0F); // Box 22
		gunModel[21].setRotationPoint(-21F, -17F, -3F);

		gunModel[22].addBox(0F, 0F, 0F, 13, 1, 4, 0F); // Box 23
		gunModel[22].setRotationPoint(-23F, -18F, -2F);

		gunModel[23].addShapeBox(0F, 0F, 0F, 17, 2, 4, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 24
		gunModel[23].setRotationPoint(-23F, -20F, -2F);

		gunModel[24].addShapeBox(0F, 0F, 0F, 2, 2, 4, 0F, 0F, 0F, -1F, 0F, 1F, -1F, 0F, 1F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 25
		gunModel[24].setRotationPoint(-6F, -20F, -2F);

		gunModel[25].addShapeBox(0F, 0F, 0F, 30, 3, 4, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 26
		gunModel[25].setRotationPoint(-4F, -21F, -2F);

		gunModel[26].addBox(0F, 0F, 0F, 11, 7, 4, 0F); // Box 27
		gunModel[26].setRotationPoint(-10F, -18F, -2F);

		gunModel[27].addBox(0F, 0F, 0F, 25, 3, 3, 0F); // Box 28
		gunModel[27].setRotationPoint(1F, -18F, -1F);

		gunModel[28].addBox(0F, 0F, 0F, 18, 3, 7, 0F); // Box 36
		gunModel[28].setRotationPoint(37F, -12.5F, -3.5F);

		gunModel[29].addShapeBox(0F, 0F, 0F, 18, 2, 7, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 39
		gunModel[29].setRotationPoint(37F, -14.5F, -3.5F);

		gunModel[30].addShapeBox(0F, 0F, 0F, 18, 2, 7, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F); // Box 40
		gunModel[30].setRotationPoint(37F, -9.5F, -3.5F);

		gunModel[31].addShapeBox(0F, 0F, 0F, 4, 2, 7, 0F, 0F, 0F, -2F, 0F, -1F, -3F, 0F, -1F, -3F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F); // Box 41
		gunModel[31].setRotationPoint(55F, -14.5F, -3.5F);

		gunModel[32].addShapeBox(0F, 0F, 0F, 4, 2, 7, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, -1F, -3F, 0F, -1F, -3F, 0F, 0F, -2F); // Box 44
		gunModel[32].setRotationPoint(55F, -9.5F, -3.5F);

		gunModel[33].addShapeBox(0F, 0F, 0F, 2, 2, 7, 0F, 0F, 0.5F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0.5F, -1F, 0F, -1F, -2.5F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, -1F, -2.5F); // Box 47
		gunModel[33].setRotationPoint(35F, -9.5F, -3.5F);

		gunModel[34].addShapeBox(0F, 0F, 0F, 2, 3, 7, 0F, 0F, -0.5F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -1F, 0F, -0.5F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -0.5F, -1F); // Box 48
		gunModel[34].setRotationPoint(35F, -12.5F, -3.5F);

		gunModel[35].addShapeBox(0F, 0F, 0F, 2, 2, 7, 0F, 0F, -1F, -2.5F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, -1F, -2.5F, 0F, 0.5F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0.5F, -1F); // Box 49
		gunModel[35].setRotationPoint(35F, -14.5F, -3.5F);

		gunModel[36].addShapeBox(0F, 0F, 0F, 15, 3, 3, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 37
		gunModel[36].setRotationPoint(26F, -20F, -3F);

		gunModel[37].addBox(0F, 0F, 0F, 24, 5, 1, 0F); // Box 38
		gunModel[37].setRotationPoint(21F, -17F, -3F);

		gunModel[38].addBox(0F, 0F, 0F, 25, 7, 1, 0F); // Box 40
		gunModel[38].setRotationPoint(1F, -18F, -2F);

		gunModel[39].addShapeBox(0F, 0F, 0F, 19, 5, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2.5F, 0F, 0F, -2.5F, 0F); // Box 41
		gunModel[39].setRotationPoint(26F, -17F, -2F);

		gunModel[40].addShapeBox(0F, 0F, 0F, 5, 3, 1, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 42
		gunModel[40].setRotationPoint(21F, -20F, -3F);

		gunModel[41].addShapeBox(0F, 0F, 0F, 4, 3, 3, 0F, 0F, 0F, -1F, -3F, 0F, -1F, -3F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 43
		gunModel[41].setRotationPoint(41F, -20F, -3F);

		gunModel[42].addShapeBox(0F, 0F, 0F, 1, 3, 2, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 44
		gunModel[42].setRotationPoint(20F, -20F, -4F);

		gunModel[43].addBox(0F, 0F, 0F, 1, 5, 2, 0F); // Box 45
		gunModel[43].setRotationPoint(20F, -17F, -4F);

		gunModel[44].addBox(0F, 0F, 0F, 15, 1, 2, 0F); // Box 56
		gunModel[44].setRotationPoint(1F, -15F, -1F);

		gunModel[45].addBox(0F, 0F, 0F, 4, 4, 6, 0F); // Box 57
		gunModel[45].setRotationPoint(-25F, -17F, -3F);

		gunModel[46].addShapeBox(0F, 0F, 0F, 4, 2, 6, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 58
		gunModel[46].setRotationPoint(-25F, -19F, -3F);

		gunModel[47].addShapeBox(0F, 0F, 0F, 3, 2, 6, 0F, 0F, 0F, -1F, -1F, 0F, -1F, -1F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 59
		gunModel[47].setRotationPoint(-25F, -21F, -3F);

		gunModel[48].addShapeBox(0F, 0F, 0F, 1, 1, 3, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 60
		gunModel[48].setRotationPoint(34.5F, -12.5F, -1.5F);

		gunModel[49].addBox(0F, 0F, 0F, 1, 1, 3, 0F); // Box 61
		gunModel[49].setRotationPoint(34.5F, -11.5F, -1.5F);

		gunModel[50].addShapeBox(0F, 0F, 0F, 1, 1, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 62
		gunModel[50].setRotationPoint(34.5F, -10.5F, -1.5F);

		gunModel[51].addShapeBox(0F, 0F, 0F, 10, 1, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F); // Box 63
		gunModel[51].setRotationPoint(16F, -14F, -1F);

		gunModel[52].addBox(0F, 0F, 0F, 10, 1, 3, 0F); // Box 64
		gunModel[52].setRotationPoint(16F, -15F, -1F);

		gunModel[53].addBox(0F, 0F, 0F, 22, 6, 6, 0F); // Box 65
		gunModel[53].setRotationPoint(-47F, -19F, -3F);

		gunModel[54].addBox(0F, 0F, 0F, 11, 10, 6, 0F); // Box 66
		gunModel[54].setRotationPoint(-47F, -13F, -3F);

		gunModel[55].addShapeBox(0F, 0F, 0F, 11, 10, 6, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -10F, 0F, 0F, -10F, 0F, 0F, 0F, 0F, 0F); // Box 67
		gunModel[55].setRotationPoint(-36F, -13F, -3F);

		gunModel[56].addShapeBox(0F, 0F, 0F, 22, 2, 6, 0F, -1F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, -1F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 68
		gunModel[56].setRotationPoint(-47F, -21F, -3F);

		gunModel[57].addShapeBox(0F, 0F, 0F, 16, 7, 2, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 69
		gunModel[57].setRotationPoint(39F, -3F, 0.5F);

		gunModel[58].addShapeBox(0F, 0F, 0F, 16, 7, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F); // Box 70
		gunModel[58].setRotationPoint(39F, -3F, 5.5F);

		gunModel[59].addShapeBox(0F, 0F, 0F, 5, 7, 2, 0F, 0F, -1F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 1F, 0F, 0F, -3F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, -1F, 0F); // Box 72
		gunModel[59].setRotationPoint(34F, -3F, 0.5F);

		gunModel[60].addShapeBox(0F, 0F, 0F, 5, 7, 2, 0F, 0F, 1F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -3F, 0F); // Box 73
		gunModel[60].setRotationPoint(34F, -3F, 5.5F);

		gunModel[61].addBox(0F, 0F, 0F, 1, 7, 7, 0F); // Box 74
		gunModel[61].setRotationPoint(33F, -4F, 0.5F);

		gunModel[62].addBox(0F, 0F, 0F, 8, 2, 2, 0F); // Box 75
		gunModel[62].setRotationPoint(26F, -6F, -1.5F);

		gunModel[63].addShapeBox(0F, 0F, 0F, 1, 2, 7, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 76
		gunModel[63].setRotationPoint(33F, -6F, 0.5F);

		gunModel[64].addShapeBox(0F, 0F, 0F, 2, 7, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 77
		gunModel[64].setRotationPoint(32F, -4F, -1.5F);

		gunModel[65].addShapeBox(0F, 0F, 0F, 1, 2, 7, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 78
		gunModel[65].setRotationPoint(25F, -6F, 0.5F);

		gunModel[66].addBox(0F, 0F, 0F, 1, 7, 7, 0F); // Box 79
		gunModel[66].setRotationPoint(25F, -4F, 0.5F);

		gunModel[67].addBox(0F, 0F, 0F, 5, 3, 1, 0F); // Box 80
		gunModel[67].setRotationPoint(-3F, -21F, -2F);

		gunModel[68].addBox(0F, 0F, 0F, 5, 3, 1, 0F); // Box 81
		gunModel[68].setRotationPoint(-3F, -21F, 1F);

		gunModel[69].addShapeBox(0F, 0F, 0F, 3, 2, 1, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 82
		gunModel[69].setRotationPoint(-2F, -22.5F, -0.5F);

		gunModel[70].addShapeBox(0F, 0F, 0F, 5, 2, 1, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 83
		gunModel[70].setRotationPoint(-3F, -23F, 1F);

		gunModel[71].addShapeBox(0F, 0F, 0F, 5, 2, 1, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 84
		gunModel[71].setRotationPoint(-3F, -23F, -2F);


		ammoModel = new ModelRendererTurbo[10];
		ammoModel[0] = new ModelRendererTurbo(this, 1, 95, textureX, textureY); // Box 46
		ammoModel[1] = new ModelRendererTurbo(this, 30, 50, textureX, textureY); // Box 47
		ammoModel[2] = new ModelRendererTurbo(this, 1, 59, textureX, textureY); // Box 48
		ammoModel[3] = new ModelRendererTurbo(this, 40, 97, textureX, textureY); // Box 49
		ammoModel[4] = new ModelRendererTurbo(this, 1, 34, textureX, textureY); // Box 50
		ammoModel[5] = new ModelRendererTurbo(this, 1, 78, textureX, textureY); // Box 52
		ammoModel[6] = new ModelRendererTurbo(this, 28, 79, textureX, textureY); // Box 53
		ammoModel[7] = new ModelRendererTurbo(this, 28, 34, textureX, textureY); // Box 54
		ammoModel[8] = new ModelRendererTurbo(this, 55, 85, textureX, textureY); // Box 55
		ammoModel[9] = new ModelRendererTurbo(this, 55, 90, textureX, textureY); // Box 56

		ammoModel[0].addShapeBox(0F, 0F, 0F, 7, 5, 12, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -7F, 0F, 0F, -7F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 46
		ammoModel[0].setRotationPoint(26F, -10F, 0.5F);

		ammoModel[1].addBox(0F, 0F, 0F, 7, 8, 14, 0F); // Box 47
		ammoModel[1].setRotationPoint(26F, -5F, 0.5F);

		ammoModel[2].addShapeBox(0F, 0F, 0F, 7, 4, 14, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -4F, 0F, 0F, -4F); // Box 48
		ammoModel[2].setRotationPoint(26F, 3F, 0.5F);

		ammoModel[3].addShapeBox(0F, 0F, 0F, 6, 3, 12, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, -3F, -1F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 49
		ammoModel[3].setRotationPoint(26.5F, -7F, -13.5F);

		ammoModel[4].addShapeBox(0F, 0F, 0F, 6, 10, 14, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, -7F, 0F, -1F, -7F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 50
		ammoModel[4].setRotationPoint(26.5F, -4F, -13.5F);

		ammoModel[5].addBox(0F, 0F, 0F, 4, 7, 9, 0F); // Box 52
		ammoModel[5].setRotationPoint(27.5F, -14F, -13.5F);

		ammoModel[6].addShapeBox(0F, 0F, 0F, 4, 6, 9, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 2F, 0F, 0F, 2F, 0F, 0F, -2F, 0F, 0F, -2F); // Box 53
		ammoModel[6].setRotationPoint(27.5F, -20F, -11.5F);

		ammoModel[7].addShapeBox(0F, 0F, 0F, 4, 4, 9, 0F, 0F, 1F, -4F, 0F, 1F, -4F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 54
		ammoModel[7].setRotationPoint(27.5F, -24F, -11.5F);

		ammoModel[8].addShapeBox(0F, 0F, 0F, 4, 1, 3, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 55
		ammoModel[8].setRotationPoint(27.5F, -10F, 5F);

		ammoModel[9].addBox(0F, 0F, 0F, 4, 1, 3, 0F); // Box 56
		ammoModel[9].setRotationPoint(27.5F, -9F, 5F);


		slideModel = new ModelRendererTurbo[1];
		slideModel[0] = new ModelRendererTurbo(this, 41, 16, textureX, textureY); // Box 29

		slideModel[0].addBox(0F, 0F, 0F, 12, 3, 3, 0F); // Box 29
		slideModel[0].setRotationPoint(15F, -12.5F, -1.5F);

//		flashModel = new ModelRendererTurbo[3][1];
//		for(int i = 0; i < 3; i++)
//		{
//			flashModel[i][0] = new ModelRendererTurbo(this, 80, 90, textureX, textureY); // Box 85
//
//			flashModel[i][0].addBox(0F, 0F, 0F, 0, 21, 21, 0F); // Box 85
//			flashModel[i][0].setRotationPoint(60F, -21.5F, -10.5F);
//		}
		hasFlash = true;
		
		animationType = EnumAnimationType.BOTTOM_CLIP;

		gunSlideDistance = -1F;

		RecoilSlideDistance = 0.1F;
		casingAnimTime = 0;

		flipAll();
		translateAll(0F, 0F, 0F);
	}
}