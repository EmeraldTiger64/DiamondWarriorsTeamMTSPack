package com.flansmod.client.model.hltp;

import com.flansmod.client.model.ModelFlash;
import com.flansmod.client.tmt.ModelRendererTurbo;

public class ModelSmallFlash extends ModelFlash
{
	int textureX = 512;
	int textureY = 256;

	public ModelSmallFlash()
	{
		flashModel = new ModelRendererTurbo[3][1];
		for(int i = 0; i < 3; i++)
		{
			flashModel[i][0] = new ModelRendererTurbo(this, 168, 32, textureX, textureY); // Box 102

			flashModel[i][0].addShapeBox(0F, 0F, 0F, 0, 21, 21, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 6F, 0F, 0F, 6F, 0F, 6F, 0F, 0F, 6F, 0F, 0F, 6F, 6F, 0F, 6F, 6F); // Box 64
			flashModel[i][0].setRotationPoint(55F, -34F, -13.5F);
		}

		flipAll();
	}
}