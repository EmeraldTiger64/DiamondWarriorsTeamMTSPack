package com.flansmod.client.model.hltp;

import com.flansmod.client.model.EnumAnimationType;
import com.flansmod.client.model.ModelGun;
import com.flansmod.client.tmt.ModelRendererTurbo;
import com.flansmod.common.vector.Vector3f;
import com.flansmod.client.tmt.Coord2D;
import com.flansmod.client.tmt.Shape2D;

public class ModelPython extends ModelGun
{
	int textureX = 512;
	int textureY = 256;

	public ModelPython()
	{
		gunModel = new ModelRendererTurbo[41];
		gunModel[0] = new ModelRendererTurbo(this, 1, 16, textureX, textureY); // Box 1
		gunModel[1] = new ModelRendererTurbo(this, 1, 4, textureX, textureY); // Box 2
		gunModel[2] = new ModelRendererTurbo(this, 1, 27, textureX, textureY); // Box 3
		gunModel[3] = new ModelRendererTurbo(this, 28, 18, textureX, textureY); // Box 4
		gunModel[4] = new ModelRendererTurbo(this, 1, 34, textureX, textureY); // Box 5
		gunModel[5] = new ModelRendererTurbo(this, 28, 26, textureX, textureY); // Box 6
		gunModel[6] = new ModelRendererTurbo(this, 30, 35, textureX, textureY); // Box 7
		gunModel[7] = new ModelRendererTurbo(this, 85, 16, textureX, textureY); // Box 8
		gunModel[8] = new ModelRendererTurbo(this, 80, 28, textureX, textureY); // Box 9
		gunModel[9] = new ModelRendererTurbo(this, 69, 28, textureX, textureY); // Box 10
		gunModel[10] = new ModelRendererTurbo(this, 56, 23, textureX, textureY); // Box 11
		gunModel[11] = new ModelRendererTurbo(this, 98, 32, textureX, textureY); // Box 12
		gunModel[12] = new ModelRendererTurbo(this, 91, 25, textureX, textureY); // Box 13
		gunModel[13] = new ModelRendererTurbo(this, 56, 1, textureX, textureY); // Box 14
		gunModel[14] = new ModelRendererTurbo(this, 56, 8, textureX, textureY); // Box 15
		gunModel[15] = new ModelRendererTurbo(this, 56, 13, textureX, textureY); // Box 16
		gunModel[16] = new ModelRendererTurbo(this, 56, 38, textureX, textureY); // Box 17
		gunModel[17] = new ModelRendererTurbo(this, 88, 38, textureX, textureY); // Box 18
		gunModel[18] = new ModelRendererTurbo(this, 56, 16, textureX, textureY); // Box 19
		gunModel[19] = new ModelRendererTurbo(this, 73, 40, textureX, textureY); // Box 20
		gunModel[20] = new ModelRendererTurbo(this, 72, 23, textureX, textureY); // Box 21
		gunModel[21] = new ModelRendererTurbo(this, 65, 23, textureX, textureY); // Box 22
		gunModel[22] = new ModelRendererTurbo(this, 109, 10, textureX, textureY); // Box 23
		gunModel[23] = new ModelRendererTurbo(this, 107, 13, textureX, textureY); // Box 24
		gunModel[24] = new ModelRendererTurbo(this, 116, 13, textureX, textureY); // Box 25
		gunModel[25] = new ModelRendererTurbo(this, 107, 13, textureX, textureY); // Box 26
		gunModel[26] = new ModelRendererTurbo(this, 56, 32, textureX, textureY); // Box 27
		gunModel[27] = new ModelRendererTurbo(this, 77, 32, textureX, textureY); // Box 28
		gunModel[28] = new ModelRendererTurbo(this, 1, 1, textureX, textureY); // Box 29
		gunModel[29] = new ModelRendererTurbo(this, 56, 51, textureX, textureY); // Box 30
		gunModel[30] = new ModelRendererTurbo(this, 8, 1, textureX, textureY); // Box 31
		gunModel[31] = new ModelRendererTurbo(this, 8, 1, textureX, textureY); // Box 32
		gunModel[32] = new ModelRendererTurbo(this, 71, 47, textureX, textureY); // Box 33
		gunModel[33] = new ModelRendererTurbo(this, 43, 44, textureX, textureY); // Box 46
		gunModel[34] = new ModelRendererTurbo(this, 36, 44, textureX, textureY); // Box 47
		gunModel[35] = new ModelRendererTurbo(this, 42, 32, textureX, textureY); // Box 48
		gunModel[36] = new ModelRendererTurbo(this, 42, 36, textureX, textureY); // Box 49
		gunModel[37] = new ModelRendererTurbo(this, 37, 2, textureX, textureY); // Box 50
		gunModel[38] = new ModelRendererTurbo(this, 37, 6, textureX, textureY); // Box 51
		gunModel[39] = new ModelRendererTurbo(this, 28, 3, textureX, textureY); // Box 52
		gunModel[40] = new ModelRendererTurbo(this, 28, 11, textureX, textureY); // Box 53

		gunModel[0].addBox(0F, 0F, 0F, 8, 5, 5, 0F); // Box 1
		gunModel[0].setRotationPoint(-6F, -10F, -2.5F);

		gunModel[1].addShapeBox(0F, 0F, 0F, 8, 6, 5, 0F, -2F, 0F, 0F, 2F, 0F, 0F, 2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 2
		gunModel[1].setRotationPoint(-6F, -16F, -2.5F);

		gunModel[2].addShapeBox(0F, 0F, 0F, 8, 1, 5, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F); // Box 3
		gunModel[2].setRotationPoint(-6F, -5F, -2.5F);

		gunModel[3].addShapeBox(0F, 0F, 0F, 4, 2, 5, 0F, 0F, 0F, 0F, -3F, 0F, 0F, -3F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 4
		gunModel[3].setRotationPoint(1F, -21F, -2.5F);

		gunModel[4].addShapeBox(0F, 0F, 0F, 9, 3, 5, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 5
		gunModel[4].setRotationPoint(-4F, -19F, -2.5F);

		gunModel[5].addBox(0F, 0F, 0F, 1, 2, 5, 0F); // Box 6
		gunModel[5].setRotationPoint(5F, -18F, -2.5F);

		gunModel[6].addBox(0F, 0F, 0F, 3, 2, 5, 0F); // Box 7
		gunModel[6].setRotationPoint(-2F, -21F, -2.5F);

		gunModel[7].addBox(0F, 0F, 0F, 7, 4, 4, 0F); // Box 8
		gunModel[7].setRotationPoint(-1F, -22F, -2F);

		gunModel[8].addShapeBox(0F, 0F, 0F, 4, 2, 1, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 9
		gunModel[8].setRotationPoint(0F, -24F, -2F);

		gunModel[9].addShapeBox(0F, 0F, 0F, 4, 2, 1, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 10
		gunModel[9].setRotationPoint(0F, -24F, 1F);

		gunModel[10].addBox(0F, 0F, 0F, 2, 4, 4, 0F); // Box 11
		gunModel[10].setRotationPoint(4F, -26F, -2F);

		gunModel[11].addBox(0F, 0F, 0F, 2, 1, 4, 0F); // Box 12
		gunModel[11].setRotationPoint(3F, -27F, -2F);

		gunModel[12].addBox(0F, 0F, 0F, 8, 2, 4, 0F); // Box 13
		gunModel[12].setRotationPoint(5F, -28F, -2F);

		gunModel[13].addBox(0F, 0F, 0F, 24, 3, 3, 0F); // Box 14
		gunModel[13].setRotationPoint(19F, -26F, -1.5F);

		gunModel[14].addBox(0F, 0F, 0F, 24, 2, 2, 0F); // Box 15
		gunModel[14].setRotationPoint(19F, -23F, -1F);

		gunModel[15].addBox(0F, 0F, 0F, 24, 1, 1, 0F); // Box 16
		gunModel[15].setRotationPoint(19F, -28F, -0.5F);

		gunModel[16].addBox(0F, 0F, 0F, 3, 3, 5, 0F); // Box 17
		gunModel[16].setRotationPoint(16F, -26F, -2.5F);

		gunModel[17].addShapeBox(0F, 0F, 0F, 3, 4, 4, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F); // Box 18
		gunModel[17].setRotationPoint(16F, -21F, -2F);

		gunModel[18].addBox(0F, 0F, 0F, 10, 2, 4, 0F); // Box 19
		gunModel[18].setRotationPoint(6F, -19F, -2F);

		gunModel[19].addBox(0F, 0F, 0F, 3, 2, 4, 0F); // Box 20
		gunModel[19].setRotationPoint(16F, -23F, -2F);

		gunModel[20].addShapeBox(0F, 0F, 0F, 2, 2, 1, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 21
		gunModel[20].setRotationPoint(2F, -26F, -2F);

		gunModel[21].addShapeBox(0F, 0F, 0F, 2, 2, 1, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 22
		gunModel[21].setRotationPoint(2F, -26F, 1F);

		gunModel[22].addBox(0F, 0F, 0F, 3, 1, 1, 0F); // Box 23
		gunModel[22].setRotationPoint(19F, -27F, -0.5F);

		gunModel[23].addBox(0F, 0F, 0F, 3, 1, 1, 0F); // Box 24
		gunModel[23].setRotationPoint(26F, -27F, -0.5F);

		gunModel[24].addBox(0F, 0F, 0F, 3, 1, 1, 0F); // Box 25
		gunModel[24].setRotationPoint(40F, -27F, -0.5F);

		gunModel[25].addBox(0F, 0F, 0F, 3, 1, 1, 0F); // Box 26
		gunModel[25].setRotationPoint(33F, -27F, -0.5F);

		gunModel[26].addBox(0F, 0F, 0F, 6, 1, 4, 0F); // Box 27
		gunModel[26].setRotationPoint(13F, -27F, -2F);

		gunModel[27].addShapeBox(0F, 0F, 0F, 6, 1, 4, 0F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, -0.5F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 28
		gunModel[27].setRotationPoint(13F, -28F, -2F);

		gunModel[28].addShapeBox(0F, 0F, 0F, 2, 1, 1, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 29
		gunModel[28].setRotationPoint(40F, -29F, -0.5F);

		gunModel[29].addBox(0F, 0F, 0F, 1, 2, 3, 0F); // Box 30
		gunModel[29].setRotationPoint(4F, -29F, -1.5F);

		gunModel[30].addBox(0F, 0F, 0F, 1, 1, 1, 0F); // Box 31
		gunModel[30].setRotationPoint(4F, -30F, -1.5F);

		gunModel[31].addBox(0F, 0F, 0F, 1, 1, 1, 0F); // Box 32
		gunModel[31].setRotationPoint(4F, -30F, 0.5F);

		gunModel[32].addBox(0F, 0F, 0F, 3, 1, 2, 0F); // Box 33
		gunModel[32].setRotationPoint(5F, -29F, -1F);

		gunModel[33].addShapeBox(0F, 0F, 0F, 1, 7, 2, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 46
		gunModel[33].setRotationPoint(5F, -26F, -3.5F);

		gunModel[34].addShapeBox(0F, 0F, 0F, 1, 7, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F); // Box 47
		gunModel[34].setRotationPoint(5F, -26F, 1.5F);

		gunModel[35].addBox(0F, 0F, 0F, 1, 2, 1, 0F); // Box 48
		gunModel[35].setRotationPoint(4F, -23.5F, 2F);

		gunModel[36].addBox(0F, 0F, 0F, 1, 2, 1, 0F); // Box 49
		gunModel[36].setRotationPoint(4F, -23.5F, -3F);

		gunModel[37].addBox(0F, 0F, 0F, 1, 1, 2, 0F); // Box 50
		gunModel[37].setRotationPoint(6F, -17F, -1F);

		gunModel[38].addShapeBox(0F, 0F, 0F, 1, 2, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F); // Box 51
		gunModel[38].setRotationPoint(6F, -16F, -1F);

		gunModel[39].addShapeBox(0F, 0F, 0F, 1, 4, 3, 0F, -1F, 0F, 0F, 1F, 0F, 0F, 1F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 52
		gunModel[39].setRotationPoint(9F, -17F, -1.5F);

		gunModel[40].addShapeBox(0F, 0F, 0F, 7, 1, 3, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F, -1F, 0F, 0F); // Box 53
		gunModel[40].setRotationPoint(3F, -13F, -1.5F);


		ammoModel = new ModelRendererTurbo[4];
		ammoModel[0] = new ModelRendererTurbo(this, 36, 67, textureX, textureY); // Box 40
		ammoModel[1] = new ModelRendererTurbo(this, 36, 62, textureX, textureY); // Box 42
		ammoModel[2] = new ModelRendererTurbo(this, 36, 62, textureX, textureY); // Box 43
		ammoModel[3] = new ModelRendererTurbo(this, 36, 67, textureX, textureY); // Box 44

		ammoModel[0].addBox(0F, 0F, 0F, 6, 4, 2, 0F); // Box 40
		ammoModel[0].setRotationPoint(5.5F, -24.5F, -3F);

		ammoModel[1].addBox(0F, 0F, 0F, 6, 2, 2, 0F); // Box 42
		ammoModel[1].setRotationPoint(5.5F, -25.5F, -1F);

		ammoModel[2].addBox(0F, 0F, 0F, 6, 2, 2, 0F); // Box 43
		ammoModel[2].setRotationPoint(5.5F, -21.5F, -1F);

		ammoModel[3].addBox(0F, 0F, 0F, 6, 4, 2, 0F); // Box 44
		ammoModel[3].setRotationPoint(5.5F, -24.5F, 1F);


		revolverBarrelModel = new ModelRendererTurbo[5];
		revolverBarrelModel[0] = new ModelRendererTurbo(this, 1, 54, textureX, textureY); // Box 34
		revolverBarrelModel[1] = new ModelRendererTurbo(this, 1, 64, textureX, textureY); // Box 35
		revolverBarrelModel[2] = new ModelRendererTurbo(this, 1, 43, textureX, textureY); // Box 36
		revolverBarrelModel[3] = new ModelRendererTurbo(this, 29, 54, textureX, textureY); // Box 37
		revolverBarrelModel[4] = new ModelRendererTurbo(this, 40, 54, textureX, textureY); // Box 38

		revolverBarrelModel[0].addShapeBox(0F, 0F, 0F, 10, 2, 7, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F); // Box 34
		revolverBarrelModel[0].setRotationPoint(6F, -26F, -3.5F);

		revolverBarrelModel[1].addShapeBox(0F, 0F, 0F, 10, 2, 7, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F, 0F, 0F, -2F); // Box 35
		revolverBarrelModel[1].setRotationPoint(6F, -21F, -3.5F);

		revolverBarrelModel[2].addBox(0F, 0F, 0F, 10, 3, 7, 0F); // Box 36
		revolverBarrelModel[2].setRotationPoint(6F, -24F, -3.5F);

		revolverBarrelModel[3].addBox(0F, 0F, 0F, 3, 2, 2, 0F); // Box 37
		revolverBarrelModel[3].setRotationPoint(16F, -23.5F, -1F);

		revolverBarrelModel[4].addBox(0F, 0F, 0F, 5, 1, 1, 0F); // Box 38
		revolverBarrelModel[4].setRotationPoint(19F, -23F, -0.5F);


		hammerModel = new ModelRendererTurbo[1];
		hammerModel[0] = new ModelRendererTurbo(this, 56, 47, textureX, textureY); // Box 55

		hammerModel[0].addShapeBox(0F, 0F, 0F, 5, 1, 2, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, 0F, -1F, 0F, 0F); // Box 55
		hammerModel[0].setRotationPoint(-1F, -24F, -1F);
		
//		flashModel = new ModelRendererTurbo[3][1];
//		for(int i = 0; i < 3; i++)
//		{
//			flashModel[i][0] = new ModelRendererTurbo(this, 1, 47, textureX, textureY); // Box 52
//
//			flashModel[i][0].addBox(0F, 0F, 0F, 0, 27, 27, 0F); // Box 52
//			flashModel[i][0].setRotationPoint(45F, -37.5F, -13.5F);
//		}
//		hasFlash = true;

		revolverFlipPoint = new Vector3f(0F /16F, 19F /16F, 3.5F /16F);
		hammerSpinPoint = new Vector3f(3F / 16F, 22F /16F, 0F / 16F);

		animationType = EnumAnimationType.REVOLVER;
		casingAnimTime = 0;

		RotateSlideDistance = -20F;
		revolverFlipAngle = -45F;

		flipAll();
		translateAll(0F, 0F, 0F);
	}
}